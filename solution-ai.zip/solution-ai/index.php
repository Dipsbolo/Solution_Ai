<?php
require_once __DIR__ . '/php/config.php';
startSecureSession();
$csrf = generateCsrf();
$db = getDB();

// Get services from DB
$services = $db->query("SELECT * FROM services WHERE is_active = 1 ORDER BY sort_order")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Solution AI - AI-powered software solutions for digital transformation">
<title>Solution AI | AI-Powered Digital Innovation</title>

<!-- Bootstrap 5 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Bootstrap Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<!-- AOS Animations -->
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

<style>
:root {
  --primary: #6C63FF;
  --primary-dark: #4B44CC;
  --secondary: #00A8CC;
  --accent: #FF6584;
  --dark: #F7F8FA;
  --dark-2: #FFFFFF;
  --dark-3: #E7E9EE;
  --text-light: #4B5263;
  --text-muted: #6B7280;
  --gradient: linear-gradient(135deg, #6C63FF 0%, #00D4FF 100%);
  --gradient-2: linear-gradient(135deg, #FF6584 0%, #6C63FF 100%);
  --glass: rgba(17, 24, 39, 0.03);
  --glass-border: rgba(17, 24, 39, 0.08);
  --heading: #1A1D29;
}

* { margin: 0; padding: 0; box-sizing: border-box; }
html { scroll-behavior: smooth; }

body {
  font-family: 'Inter', sans-serif;
  background: var(--dark);
  color: var(--text-light);
  overflow-x: hidden;
}

/* ===== NAVBAR ===== */
#mainNav {
  background: rgba(255, 255, 255, 0.85);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--glass-border);
  transition: all 0.3s ease;
  padding: 12px 0;
}
#mainNav.scrolled { background: rgba(255,255,255,0.97); box-shadow: 0 4px 30px rgba(108,99,255,0.1); }
.navbar-brand span { background: var(--gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-weight: 900; font-size: 1.6rem; }
.nav-link { color: var(--heading) !important; font-weight: 500; font-size: 0.92rem; padding: 6px 14px !important; border-radius: 8px; transition: all 0.2s; }
.nav-link:hover, .nav-link.active { color: var(--primary-dark) !important; background: var(--glass); }
.btn-nav-cta { background: var(--gradient); color: #fff !important; border-radius: 25px !important; padding: 8px 22px !important; font-weight: 600; }
.btn-nav-cta:hover { opacity: 0.9; transform: translateY(-1px); }
.navbar-toggler i { color: var(--heading) !important; }

/* ===== HERO ===== */
#home {
  min-height: 100vh;
  background: var(--dark);
  position: relative;
  display: flex;
  align-items: center;
  overflow: hidden;
}
.hero-bg {
  position: absolute; inset: 0;
  background: radial-gradient(ellipse at 20% 50%, rgba(108,99,255,0.08) 0%, transparent 60%),
              radial-gradient(ellipse at 80% 20%, rgba(0,212,255,0.08) 0%, transparent 60%),
              radial-gradient(ellipse at 60% 80%, rgba(255,101,132,0.06) 0%, transparent 50%);
}
.hero-grid {
  position: absolute; inset: 0;
  background-image: linear-gradient(rgba(17,24,39,0.04) 1px, transparent 1px),
                    linear-gradient(90deg, rgba(108,99,255,0.05) 1px, transparent 1px);
  background-size: 60px 60px;
}
.hero-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(108,99,255,0.08); border: 1px solid rgba(108,99,255,0.25); border-radius: 50px; padding: 6px 18px; font-size: 0.82rem; color: var(--primary-dark); font-weight: 600; margin-bottom: 24px; }
.hero-title { font-size: clamp(2.4rem, 6vw, 4.5rem); font-weight: 900; line-height: 1.1; color: var(--heading); }
.hero-title .gradient-text { background: var(--gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.hero-desc { font-size: 1.1rem; color: var(--text-light); max-width: 580px; line-height: 1.7; }
.btn-primary-gradient { background: var(--gradient); border: none; color: #fff; font-weight: 700; padding: 14px 32px; border-radius: 50px; font-size: 1rem; transition: all 0.3s; box-shadow: 0 8px 30px rgba(108,99,255,0.3); }
.btn-primary-gradient:hover { transform: translateY(-3px); box-shadow: 0 12px 40px rgba(108,99,255,0.4); color: #fff; }
.btn-outline-light-custom { border: 1px solid var(--glass-border); color: var(--heading); font-weight: 600; padding: 14px 32px; border-radius: 50px; font-size: 1rem; background: #fff; transition: all 0.3s; }
.btn-outline-light-custom:hover { background: var(--dark-3); color: var(--heading); }
.hero-stats { display: flex; gap: 40px; margin-top: 48px; }
.stat-item { text-align: center; }
.stat-num { font-size: 2rem; font-weight: 900; background: var(--gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.stat-label { font-size: 0.78rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; }
.hero-visual { position: relative; }
.hero-card { background: #fff; border: 1px solid var(--glass-border); border-radius: 20px; padding: 20px; backdrop-filter: blur(20px); box-shadow: 0 20px 60px rgba(17,24,39,0.08); }
.floating-badge { position: absolute; background: rgba(108,99,255,0.95); backdrop-filter: blur(10px); border-radius: 12px; padding: 10px 16px; font-size: 0.8rem; font-weight: 600; color: #fff; white-space: nowrap; border: 1px solid rgba(255,255,255,0.15); box-shadow: 0 8px 24px rgba(108,99,255,0.25); }

/* ===== SECTIONS ===== */
section { padding: 100px 0; }
.section-label { font-size: 0.8rem; font-weight: 700; text-transform: uppercase; letter-spacing: 3px; background: var(--gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 12px; }
.section-title { font-size: clamp(1.8rem, 4vw, 2.8rem); font-weight: 800; color: var(--heading); line-height: 1.2; }
.section-desc { color: var(--text-light); font-size: 1.05rem; max-width: 600px; margin: 0 auto; }

/* ===== GLASS CARDS ===== */
.glass-card { background: #fff; border: 1px solid var(--glass-border); border-radius: 20px; padding: 32px; transition: all 0.3s ease; box-shadow: 0 1px 3px rgba(17,24,39,0.04); }
.glass-card:hover { border-color: rgba(108,99,255,0.35); transform: translateY(-6px); box-shadow: 0 20px 50px rgba(108,99,255,0.12); }
.icon-box { width: 56px; height: 56px; border-radius: 14px; background: var(--gradient); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: #fff; margin-bottom: 20px; }
.card-title-s { font-size: 1.1rem; font-weight: 700; color: var(--heading); margin-bottom: 10px; }
.card-desc { color: var(--text-light); font-size: 0.9rem; line-height: 1.6; }

/* ===== SERVICES SECTION ===== */
#services { background: var(--dark-3); }

/* ===== SOLUTIONS ===== */
#solutions { background: var(--dark); }
.solution-item { display: flex; gap: 24px; align-items: flex-start; padding: 28px; border-radius: 16px; border: 1px solid var(--glass-border); background: #fff; transition: all 0.3s; }
.solution-item:hover { border-color: rgba(108,99,255,0.3); box-shadow: 0 12px 30px rgba(108,99,255,0.1); }
.solution-num { font-size: 2.5rem; font-weight: 900; background: var(--gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; line-height: 1; min-width: 60px; }

/* ===== EVENTS ===== */
#events { background: var(--dark-3); }
.event-card { border-radius: 16px; overflow: hidden; border: 1px solid var(--glass-border); background: #fff; transition: all 0.3s; box-shadow: 0 1px 3px rgba(17,24,39,0.04); }
.event-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(17,24,39,0.1); }
.event-date-badge { background: var(--gradient); color: #fff; font-weight: 700; font-size: 0.8rem; padding: 4px 12px; border-radius: 20px; display: inline-block; margin-bottom: 12px; }
.event-img { width: 100%; height: 200px; object-fit: cover; }
.event-body { padding: 20px; }
.upcoming-tag { background: rgba(0,168,204,0.1); color: var(--secondary); border: 1px solid rgba(0,168,204,0.3); font-size: 0.75rem; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
.past-tag { background: rgba(255,101,132,0.1); color: var(--accent); border: 1px solid rgba(255,101,132,0.3); font-size: 0.75rem; padding: 3px 10px; border-radius: 20px; font-weight: 600; }

/* ===== CLIENTS ===== */
#clients { background: var(--dark); }
.testimonial-card { background: #fff; border: 1px solid var(--glass-border); border-radius: 20px; padding: 28px; box-shadow: 0 1px 3px rgba(17,24,39,0.04); }
.stars { color: #FBBF24; font-size: 1rem; }
.client-quote { font-size: 0.95rem; color: var(--text-light); line-height: 1.7; margin: 16px 0; font-style: italic; }
.client-info { display: flex; align-items: center; gap: 12px; }
.client-avatar { width: 46px; height: 46px; border-radius: 50%; background: var(--gradient); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 1.1rem; color: #fff; }
.client-name { font-weight: 700; color: var(--heading); font-size: 0.95rem; }
.client-role { font-size: 0.8rem; color: var(--text-muted); }
.logo-row { display: flex; flex-wrap: wrap; justify-content: center; align-items: center; gap: 40px; margin-top: 60px; }
.logo-item { background: #fff; border: 1px solid var(--glass-border); border-radius: 12px; padding: 16px 28px; font-size: 1.1rem; font-weight: 700; color: var(--text-muted); transition: all 0.3s; }
.logo-item:hover { color: var(--primary-dark); border-color: rgba(108,99,255,0.4); }

/* ===== GALLERY ===== */
#gallery { background: var(--dark-3); }
.gallery-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
.gallery-item { position: relative; border-radius: 16px; overflow: hidden; cursor: pointer; aspect-ratio: 4/3; background: #fff; border: 1px solid var(--glass-border); }
.gallery-item::before { content: ''; position: absolute; inset: 0; background: var(--gradient); opacity: 0; transition: opacity 0.3s; z-index: 1; }
.gallery-item:hover::before { opacity: 0.25; }
.gallery-placeholder { width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px; font-size: 2.5rem; color: rgba(255,255,255,0.3); }
.gallery-overlay { position: absolute; inset: 0; background: rgba(17,24,39,0.55); display: flex; align-items: center; justify-content: center; opacity: 0; transition: all 0.3s; z-index: 2; }
.gallery-item:hover .gallery-overlay { opacity: 1; }

/* ===== CONTACT ===== */
#contact { background: var(--dark); }
.contact-form-wrapper { background: #fff; border: 1px solid var(--glass-border); border-radius: 24px; padding: 48px; box-shadow: 0 1px 3px rgba(17,24,39,0.04); }
.form-control, .form-select { background: var(--dark) !important; border: 1px solid var(--glass-border) !important; color: var(--heading) !important; border-radius: 12px !important; padding: 12px 16px !important; transition: all 0.3s; }
.form-control:focus, .form-select:focus { background: #fff !important; border-color: var(--primary) !important; box-shadow: 0 0 0 3px rgba(108,99,255,0.15) !important; }
.form-control::placeholder { color: var(--text-muted) !important; }
.form-select option { background: #fff; color: var(--heading); }
.form-label { font-weight: 600; font-size: 0.88rem; color: var(--heading); margin-bottom: 6px; }

/* ===== FOOTER ===== */
footer { background: #fff; border-top: 1px solid var(--glass-border); padding: 60px 0 30px; }
.footer-brand { font-size: 1.6rem; font-weight: 900; background: var(--gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.footer-desc { color: var(--text-light); font-size: 0.9rem; margin-top: 12px; max-width: 280px; }
.footer-heading { font-weight: 700; color: var(--heading); margin-bottom: 20px; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; }
.footer-link { color: var(--text-muted); text-decoration: none; display: block; padding: 4px 0; font-size: 0.9rem; transition: color 0.2s; }
.footer-link:hover { color: var(--primary); }
.social-link { width: 40px; height: 40px; border-radius: 10px; background: var(--dark-3); border: 1px solid var(--glass-border); display: inline-flex; align-items: center; justify-content: center; color: var(--text-muted); transition: all 0.3s; text-decoration: none; margin-right: 8px; }
.social-link:hover { background: var(--primary); color: #fff; border-color: var(--primary); }
.footer-divider { border-color: var(--glass-border); margin: 40px 0 20px; }

/* ===== BACK TO TOP ===== */
#backToTop { position: fixed; bottom: 90px; right: 24px; width: 44px; height: 44px; background: var(--gradient); border-radius: 12px; border: none; color: #fff; font-size: 1.1rem; display: none; align-items: center; justify-content: center; cursor: pointer; z-index: 999; box-shadow: 0 4px 20px rgba(108,99,255,0.35); transition: all 0.3s; }
#backToTop.show { display: flex; }
#backToTop:hover { transform: translateY(-3px); }

/* Override Bootstrap text-white for light theme cards (most text-white sits on light backgrounds now) */
.text-white { color: var(--heading) !important; }
/* Exceptions: text that sits on dark/gradient backgrounds and must stay literal white */
.gallery-overlay .text-white,
.msg-avatar .text-white,
.chat-header .text-white,
#chatWindow .text-white { color: #fff !important; }

/* ===== ANIMATIONS ===== */
@keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }
@keyframes pulse-ring { 0%{transform:scale(1);opacity:0.6} 100%{transform:scale(1.6);opacity:0} }
.animate-float { animation: float 4s ease-in-out infinite; }
.pulse-dot { position: relative; width: 10px; height: 10px; border-radius: 50%; background: #22C55E; display: inline-block; }
.pulse-dot::after { content:''; position:absolute; inset:-4px; border-radius:50%; border: 2px solid #22C55E; animation: pulse-ring 1.5s infinite; }

/* Responsive */
@media (max-width: 768px) {
  section { padding: 70px 0; }
  .hero-stats { gap: 24px; }
  .contact-form-wrapper { padding: 28px; }
  .hero-title { font-size: 2.2rem; }
}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav id="mainNav" class="navbar navbar-expand-lg fixed-top">
  <div class="container">
    <a class="navbar-brand" href="#home">
      <span><i class="bi bi-hexagon-fill me-1"></i>Solution AI</span>
    </a>
    <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
      <i class="bi bi-list fs-4" style="color:var(--heading)"></i>
    </button>
    <div class="collapse navbar-collapse" id="navContent">
      <ul class="navbar-nav mx-auto gap-1">
        <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="#solutions">Solutions</a></li>
        <li class="nav-item"><a class="nav-link" href="#events">Events</a></li>
        <li class="nav-item"><a class="nav-link" href="#clients">Clients</a></li>
        <li class="nav-item"><a class="nav-link" href="#gallery">Gallery</a></li>
        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
      </ul>
      <a href="#contact" class="btn btn-nav-cta">Get Started</a>
    </div>
  </div>
</nav>

<!-- ===== HERO ===== -->
<section id="home">
  <div class="hero-bg"></div>
  <div class="hero-grid"></div>
  <div class="container position-relative">
    <div class="row align-items-center min-vh-100 py-5">
      <div class="col-lg-6" data-aos="fade-right">
        <div class="hero-badge">
          <span class="pulse-dot"></span> Sunderland's #1 AI Innovation Company
        </div>
        <h1 class="hero-title mb-4">
          Shaping the Future of <span class="gradient-text">Digital Work</span> with AI
        </h1>
        <p class="hero-desc mb-5">
          Solution AI empowers businesses with cutting-edge AI software — from intelligent chatbots to predictive analytics — delivering rapid, affordable innovation that transforms the digital employee experience.
        </p>
        <div class="d-flex flex-wrap gap-3 mb-4">
          <a href="#contact" class="btn btn-primary-gradient"><i class="bi bi-rocket-takeoff me-2"></i>Start Your AI Journey</a>
          <a href="#solutions" class="btn btn-outline-light-custom"><i class="bi bi-play-circle me-2"></i>See Our Solutions</a>
        </div>
        <div class="hero-stats">
          <div class="stat-item"><div class="stat-num">500+</div><div class="stat-label">Projects Delivered</div></div>
          <div class="stat-item"><div class="stat-num">98%</div><div class="stat-label">Client Satisfaction</div></div>
          <div class="stat-item"><div class="stat-num">40+</div><div class="stat-label">Countries Served</div></div>
        </div>
      </div>
      <div class="col-lg-6 mt-5 mt-lg-0" data-aos="fade-left">
        <div class="hero-visual text-center position-relative">
          <div class="hero-card animate-float">
            <div class="row g-3">
              <div class="col-6">
                <div class="glass-card text-center p-3">
                  <i class="bi bi-cpu-fill fs-2 mb-2" style="color:var(--primary)"></i>
                  <div class="fw-700 text-white small">Machine Learning</div>
                </div>
              </div>
              <div class="col-6">
                <div class="glass-card text-center p-3">
                  <i class="bi bi-chat-dots-fill fs-2 mb-2" style="color:var(--secondary)"></i>
                  <div class="fw-700 text-white small">AI Chatbots</div>
                </div>
              </div>
              <div class="col-6">
                <div class="glass-card text-center p-3">
                  <i class="bi bi-bar-chart-fill fs-2 mb-2" style="color:var(--accent)"></i>
                  <div class="fw-700 text-white small">Data Analytics</div>
                </div>
              </div>
              <div class="col-6">
                <div class="glass-card text-center p-3">
                  <i class="bi bi-eye-fill fs-2 mb-2" style="color:#FBBF24"></i>
                  <div class="fw-700 text-white small">Computer Vision</div>
                </div>
              </div>
            </div>
            <div class="mt-3 p-3 rounded-3" style="background:rgba(108,99,255,0.1);border:1px solid rgba(108,99,255,0.2)">
              <div class="d-flex align-items-center gap-2 mb-2">
                <i class="bi bi-activity text-success"></i>
                <small class="text-white fw-600">AI Performance Live</small>
              </div>
              <div class="d-flex justify-content-between mb-1">
                <small class="text-muted">Accuracy</small>
                <small class="text-white fw-600">98.7%</small>
              </div>
              <div class="progress mb-2" style="height:4px;background:rgba(17,24,39,0.08)">
                <div class="progress-bar" style="width:98.7%;background:var(--gradient)"></div>
              </div>
              <div class="d-flex justify-content-between mb-1">
                <small class="text-muted">Processing Speed</small>
                <small class="text-white fw-600">< 50ms</small>
              </div>
              <div class="progress" style="height:4px;background:rgba(17,24,39,0.08)">
                <div class="progress-bar" style="width:95%;background:linear-gradient(90deg,#00D4FF,#6C63FF)"></div>
              </div>
            </div>
          </div>
          <div class="floating-badge" style="top:-15px;right:-10px;animation:float 3s ease-in-out infinite">
            <i class="bi bi-shield-check text-success me-1"></i> Enterprise Grade AI
          </div>
          <div class="floating-badge" style="bottom:-10px;left:-20px;animation:float 4s ease-in-out infinite 0.5s">
            <i class="bi bi-lightning-fill" style="color:#FBBF24"></i> 10x Faster Deployment
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ===== SERVICES ===== -->
<section id="services">
  <div class="container">
    <div class="text-center mb-5" data-aos="fade-up">
      <div class="section-label">What We Offer</div>
      <h2 class="section-title">AI Services Tailored for <br>Your Business Growth</h2>
      <p class="section-desc mt-3">From intelligent automation to predictive analytics, our AI solutions are designed to solve real business challenges at scale.</p>
    </div>
    <div class="row g-4">
      <?php foreach ($services as $i => $svc): ?>
      <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="<?= $i * 50 ?>">
        <div class="glass-card h-100">
          <div class="icon-box"><i class="bi <?= htmlspecialchars($svc['icon']) ?>"></i></div>
          <div class="card-title-s"><?= htmlspecialchars($svc['title']) ?></div>
          <div class="card-desc"><?= htmlspecialchars($svc['description']) ?></div>
          <a href="#contact" class="d-inline-flex align-items-center gap-1 mt-3 text-decoration-none" style="color:var(--primary);font-size:0.85rem;font-weight:600">
            Learn More <i class="bi bi-arrow-right"></i>
          </a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ===== SOLUTIONS ===== -->
<section id="solutions">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-5" data-aos="fade-right">
        <div class="section-label">Industry Solutions</div>
        <h2 class="section-title mb-4">AI Solutions That Drive Real Results</h2>
        <p class="mb-4" style="color:var(--text-light)">We've helped organisations across industries leverage AI to reduce costs, increase efficiency, and accelerate innovation.</p>
        <div class="d-flex flex-column gap-3">
          <div class="solution-item">
            <div class="solution-num">01</div>
            <div>
              <h5 class="text-white fw-700 mb-1">Healthcare AI</h5>
              <p class="text-muted small mb-0">Diagnostic AI, patient management automation, and predictive health analytics reducing admin time by 60%.</p>
            </div>
          </div>
          <div class="solution-item">
            <div class="solution-num">02</div>
            <div>
              <h5 class="text-white fw-700 mb-1">Financial Services</h5>
              <p class="text-muted small mb-0">Real-time fraud detection, automated compliance, and AI-driven risk assessment for banks and insurers.</p>
            </div>
          </div>
          <div class="solution-item">
            <div class="solution-num">03</div>
            <div>
              <h5 class="text-white fw-700 mb-1">Retail & E-commerce</h5>
              <p class="text-muted small mb-0">Personalisation engines, demand forecasting, and AI-powered inventory optimisation increasing revenue by 35%.</p>
            </div>
          </div>
          <div class="solution-item">
            <div class="solution-num">04</div>
            <div>
              <h5 class="text-white fw-700 mb-1">Manufacturing</h5>
              <p class="text-muted small mb-0">Predictive maintenance, quality control via computer vision, and smart supply chain automation.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-7" data-aos="fade-left">
        <div class="row g-3">
          <div class="col-6">
            <div class="glass-card text-center p-4">
              <div class="stat-num fs-1 mb-1">60%</div>
              <div class="text-muted small">Reduction in Operational Costs</div>
            </div>
          </div>
          <div class="col-6">
            <div class="glass-card text-center p-4">
              <div class="stat-num fs-1 mb-1">3x</div>
              <div class="text-muted small">Faster Product Development</div>
            </div>
          </div>
          <div class="col-12">
            <div class="glass-card">
              <h6 class="text-white fw-700 mb-3">AI Integration Success Rate</h6>
              <div class="mb-3">
                <div class="d-flex justify-content-between mb-1">
                  <span class="small text-muted">Customer Satisfaction</span>
                  <span class="small text-white fw-600">98%</span>
                </div>
                <div class="progress" style="height:6px;background:rgba(17,24,39,0.08)"><div class="progress-bar" style="width:98%;background:var(--gradient)"></div></div>
              </div>
              <div class="mb-3">
                <div class="d-flex justify-content-between mb-1">
                  <span class="small text-muted">On-Time Delivery</span>
                  <span class="small text-white fw-600">95%</span>
                </div>
                <div class="progress" style="height:6px;background:rgba(17,24,39,0.08)"><div class="progress-bar" style="width:95%;background:linear-gradient(90deg,#00D4FF,#6C63FF)"></div></div>
              </div>
              <div>
                <div class="d-flex justify-content-between mb-1">
                  <span class="small text-muted">ROI Achieved Within 12 Months</span>
                  <span class="small text-white fw-600">89%</span>
                </div>
                <div class="progress" style="height:6px;background:rgba(17,24,39,0.08)"><div class="progress-bar" style="width:89%;background:linear-gradient(90deg,#FF6584,#6C63FF)"></div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ===== EVENTS ===== -->
<section id="events">
  <div class="container">
    <div class="text-center mb-5" data-aos="fade-up">
      <div class="section-label">Events & Highlights</div>
      <h2 class="section-title">Stay Connected with <br>the AI Revolution</h2>
    </div>
    <!-- Upcoming Events -->
    <h5 class="text-white fw-700 mb-4" data-aos="fade-up"><span class="upcoming-tag me-2">UPCOMING</span> Upcoming Events</h5>
    <div class="row g-4 mb-5">
      <?php
      $upcoming_events = [
        ['title'=>'AI Innovation Summit 2025','date'=>'15 Aug 2025','location'=>'ExCeL London','image'=>'images/generated/event-ai-summit.png'],
        ['title'=>'Digital Transformation Expo','date'=>'22 Sep 2025','location'=>'Manchester Central','image'=>'images/generated/event-digital-expo.png'],
        ['title'=>'Solution AI Annual Tech Conference','date'=>'10 Oct 2025','location'=>'Sunderland Stadium','image'=>'images/1.jpeg'],
      ];
      foreach ($upcoming_events as $i => $ev): ?>
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="<?= $i*100 ?>">
        <div class="event-card">
          <div class="p-0" style="height:160px;overflow:hidden">
            <img src="<?= $ev['image'] ?>" alt="<?= htmlspecialchars($ev['title']) ?>" class="event-img" style="height:160px">
          </div>
          <div class="event-body">
            <div class="upcoming-tag mb-2">Upcoming</div>
            <h6 class="text-white fw-700 mb-2"><?= $ev['title'] ?></h6>
            <div class="d-flex gap-3 text-muted small">
              <span><i class="bi bi-calendar me-1"></i><?= $ev['date'] ?></span>
              <span><i class="bi bi-geo-alt me-1"></i><?= $ev['location'] ?></span>
            </div>
            <a href="#contact" class="btn btn-sm mt-3" style="background:var(--gradient);color:#fff;border-radius:20px;padding:6px 18px;font-size:0.82rem">Register Now</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Past Events -->
    <h5 class="text-white fw-700 mb-4" data-aos="fade-up"><span class="past-tag me-2">PAST</span> Past Events</h5>
    <div class="row g-4">
      <?php
      $past_events = [
        ['title'=>'AI in Healthcare Symposium 2024','date'=>'Nov 2024','attendees'=>'800+','image'=>'images/Healthcare.jpeg'],
        ['title'=>'Smart Manufacturing AI Workshop','date'=>'Sep 2024','attendees'=>'350+','image'=>'images/generated/event-manufacturing-workshop.png'],
        ['title'=>'Retail AI Innovation Day','date'=>'Jul 2024','attendees'=>'500+','image'=>'images/generated/event-retail-innovation.png'],
      ];
      foreach ($past_events as $i => $ev): ?>
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="<?= $i*100 ?>">
        <div class="event-card">
          <div class="p-0" style="height:140px;overflow:hidden">
            <img src="<?= $ev['image'] ?>" alt="<?= htmlspecialchars($ev['title']) ?>" class="event-img" style="height:140px;opacity:0.85">
          </div>
          <div class="event-body">
            <div class="past-tag mb-2">Past Event</div>
            <h6 class="text-white fw-700 mb-2"><?= $ev['title'] ?></h6>
            <div class="d-flex gap-3 text-muted small">
              <span><i class="bi bi-calendar me-1"></i><?= $ev['date'] ?></span>
              <span><i class="bi bi-people me-1"></i><?= $ev['attendees'] ?> Attendees</span>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ===== CLIENTS ===== -->
<section id="clients">
  <div class="container">
    <div class="text-center mb-5" data-aos="fade-up">
      <div class="section-label">Trusted By Leaders</div>
      <h2 class="section-title">What Our Clients Say</h2>
    </div>
    <div class="row g-4">
      <?php
      $testimonials = [
        ['name'=>'Sarah Mitchell','role'=>'CTO, MediCore Health','rating'=>5,'quote'=>'Solution AI transformed our patient intake system completely. Their AI chatbot handles 78% of queries automatically, saving our team 15 hours weekly. Truly exceptional work.','initials'=>'SM'],
        ['name'=>'James Patterson','role'=>'Head of Digital, FinEdge Bank','rating'=>5,'quote'=>'The fraud detection ML model they built for us has reduced false positives by 40% while catching 30% more genuine fraud. The ROI was visible within 3 months.','initials'=>'JP'],
        ['name'=>'Priya Sharma','role'=>'VP Operations, RetailNow','rating'=>5,'quote'=>'Our demand forecasting accuracy improved from 65% to 94% with Solution AI\'s solution. The team was professional, fast, and delivered beyond our expectations.','initials'=>'PS'],
        ['name'=>'David Chen','role'=>'CEO, LogiTech Manufacturing','rating'=>5,'quote'=>'Computer vision quality control reduced our defect rate by 85%. Solution AI didn\'t just build software — they understood our business and delivered real value.','initials'=>'DC'],
        ['name'=>'Emma Thompson','role'=>'Director, EduFuture','rating'=>5,'quote'=>'The personalised learning AI has increased student engagement by 60%. Solution AI\'s support team is incredible — always available and truly invested in our success.','initials'=>'ET'],
        ['name'=>'Marcus Weber','role'=>'COO, EnergyPro','rating'=>5,'quote'=>'Predictive maintenance AI saved us £2M in the first year by preventing equipment failures. A game-changer for our entire operations team.','initials'=>'MW'],
      ];
      foreach ($testimonials as $i => $t): ?>
      <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?= $i*75 ?>">
        <div class="testimonial-card h-100">
          <div class="stars"><?= str_repeat('★', $t['rating']) ?></div>
          <p class="client-quote">"<?= $t['quote'] ?>"</p>
          <div class="client-info">
            <div class="client-avatar"><?= $t['initials'] ?></div>
            <div>
              <div class="client-name"><?= $t['name'] ?></div>
              <div class="client-role"><?= $t['role'] ?></div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <!-- Client Logos -->
    <div class="logo-row" data-aos="fade-up">
      <?php
      $logos = ['MediCore Health','FinEdge Bank','RetailNow','LogiTech','EduFuture','EnergyPro','GlobalAI Corp','NextGen Tech'];
      foreach ($logos as $logo): ?>
      <div class="logo-item"><?= $logo ?></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ===== GALLERY ===== -->
<section id="gallery">
  <div class="container">
    <div class="text-center mb-5" data-aos="fade-up">
      <div class="section-label">Photo Gallery</div>
      <h2 class="section-title">Moments That Define Us</h2>
      <p class="section-desc mt-3">Behind-the-scenes looks at our events, team, and the innovations we're building.</p>
    </div>
    <div class="gallery-grid">
      <?php
      $gallery_images = [
        ['image'=>'images/generated/gallery-team-summit.png','label'=>'Team Summit 2024'],
        ['image'=>'images/generated/gallery-ai-lab-tour.png','label'=>'AI Lab Tour'],
        ['image'=>'images/generated/gallery-award-ceremony.png','label'=>'Award Ceremony'],
        ['image'=>'images/generated/gallery-global-conference.png','label'=>'Global Conference'],
        ['image'=>'images/generated/gallery-innovation-workshop.png','label'=>'Innovation Workshop'],
        ['image'=>'images/generated/gallery-demo-day.png','label'=>'Demo Day'],
      ];
      foreach ($gallery_images as $i => $g): ?>
      <div class="gallery-item" data-aos="zoom-in" data-aos-delay="<?= $i*60 ?>">
        <img src="<?= $g['image'] ?>" alt="<?= htmlspecialchars($g['label']) ?>" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0">
        <div class="gallery-overlay">
          <i class="bi bi-zoom-in text-white fs-2"></i>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ===== CONTACT ===== -->
<section id="contact">
  <div class="container">
    <div class="row g-5 align-items-start">
      <div class="col-lg-4" data-aos="fade-right">
        <div class="section-label">Get In Touch</div>
        <h2 class="section-title mb-4">Let's Build Your AI Future Together</h2>
        <p style="color:var(--text-light)" class="mb-4">Share your project requirements and our AI specialists will get back to you within 24 hours with a tailored proposal.</p>
        <div class="d-flex flex-column gap-3">
          <div class="glass-card p-3 d-flex align-items-center gap-3">
            <div class="icon-box" style="width:44px;height:44px;min-width:44px"><i class="bi bi-envelope-fill fs-5"></i></div>
            <div><div class="small text-muted">Email Us</div><div class="text-white fw-600 small">deepak.sah.450045.com</div></div>
          </div>
          <div class="glass-card p-3 d-flex align-items-center gap-3">
            <div class="icon-box" style="width:44px;height:44px;min-width:44px;background:linear-gradient(135deg,#00D4FF,#6C63FF)"><i class="bi bi-telephone-fill fs-5"></i></div>
            <div><div class="small text-muted">Call Us</div><div class="text-white fw-600 small">+977-9815744151</div></div>
          </div>
          <div class="glass-card p-3 d-flex align-items-center gap-3">
            <div class="icon-box" style="width:44px;height:44px;min-width:44px;background:linear-gradient(135deg,#FF6584,#6C63FF)"><i class="bi bi-geo-alt-fill fs-5"></i></div>
            <div><div class="small text-muted">Location</div><div class="text-white fw-600 small">Kathmandu, iSMT</div></div>
          </div>
        </div>
      </div>
      <div class="col-lg-8" data-aos="fade-left">
        <div class="contact-form-wrapper">
          <h4 class="text-white fw-700 mb-4">Send Us Your Requirements</h4>
          <div id="formAlert" class="alert d-none"></div>
          <form id="contactForm">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label">Full Name *</label>
                <input type="text" class="form-control" name="name" placeholder="John Smith" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Email Address *</label>
                <input type="email" class="form-control" name="email" placeholder="john@company.com" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Phone Number *</label>
                <input type="tel" class="form-control" name="phone" placeholder="+977 xxxx xxxxxx" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Company Name *</label>
                <input type="text" class="form-control" name="company_name" placeholder="Your Company Ltd" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Country *</label>
                <select class="form-select" name="country" required>
                  <option value="">Select Country</option>
                  <option>United Kingdom</option><option>United States</option><option>Germany</option>
                  <option>France</option><option>India</option><option>Australia</option>
                  <option>Canada</option><option>Singapore</option><option>UAE</option><option>Other</option>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label">Job Title *</label>
                <input type="text" class="form-control" name="job_title" placeholder="CTO / CEO / Director" required>
              </div>
              <div class="col-12">
                <label class="form-label">Project / Job Details *</label>
                <textarea class="form-control" name="job_details" rows="5" placeholder="Please describe your project requirements, goals, and any specific AI solutions you're looking for..." required></textarea>
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-primary-gradient w-100" id="submitBtn">
                  <i class="bi bi-send-fill me-2"></i>Submit Inquiry
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer>
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4">
        <div class="footer-brand"><i class="bi bi-hexagon-fill me-1"></i>Solution AI</div>
        <p class="footer-desc">Innovating the future of digital work through affordable, intelligent AI solutions for businesses worldwide.</p>
        <div class="mt-4">
          <a href="#" class="social-link"><i class="bi bi-linkedin"></i></a>
          <a href="#" class="social-link"><i class="bi bi-twitter-x"></i></a>
          <a href="#" class="social-link"><i class="bi bi-github"></i></a>
          <a href="#" class="social-link"><i class="bi bi-youtube"></i></a>
        </div>
      </div>
      <div class="col-lg-2 col-md-4">
        <div class="footer-heading">Services</div>
        <a href="#services" class="footer-link">AI Chatbots</a>
        <a href="#services" class="footer-link">Machine Learning</a>
        <a href="#services" class="footer-link">Data Analytics</a>
        <a href="#services" class="footer-link">NLP Solutions</a>
        <a href="#services" class="footer-link">AI Consulting</a>
      </div>
      <div class="col-lg-2 col-md-4">
        <div class="footer-heading">Company</div>
        <a href="#home" class="footer-link">About Us</a>
        <a href="#solutions" class="footer-link">Solutions</a>
        <a href="#clients" class="footer-link">Case Studies</a>
        <a href="#events" class="footer-link">Events</a>
        <a href="#contact" class="footer-link">Contact</a>
      </div>
      <div class="col-lg-4 col-md-4">
        <div class="footer-heading">Newsletter</div>
        <p class="text-muted small mb-3">Stay updated with the latest AI trends and Solution AI news.</p>
        <div class="input-group">
          <input type="email" class="form-control" placeholder="your@email.com">
          <button class="btn" style="background:var(--gradient);color:#fff;border:none">Subscribe</button>
        </div>
      </div>
    </div>
    <hr class="footer-divider">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
      <p class="text-muted small mb-0">© 2026 Solution AI. All rights reserved.</p>
      <div class="d-flex gap-3">
        <a href="#" class="footer-link d-inline" style="font-size:0.82rem">Privacy Policy</a>
        <a href="#" class="footer-link d-inline" style="font-size:0.82rem">Terms of Service</a>
        <a href="admin/login.php" class="footer-link d-inline" style="font-size:0.82rem"><i class="bi bi-lock me-1"></i>Admin</a>
      </div>
    </div>
  </div>
</footer>

<!-- Back to Top -->
<button id="backToTop"><i class="bi bi-chevron-up"></i></button>

<!-- ===== CHATBOT WIDGET ===== -->
<div id="chatWidget">
  <!-- Toggle Button -->
  <button id="chatToggle" onclick="toggleChat()">
    <i class="bi bi-chat-dots-fill" id="chatIcon"></i>
    <span class="chat-badge" id="chatBadge" style="display:none">1</span>
  </button>

  <!-- Chat Window -->
  <div id="chatWindow" style="display:none">
    <!-- Header -->
    <div class="chat-header">
      <div class="chat-agent-info">
        <div class="agent-avatar"><i class="bi bi-robot"></i></div>
        <div>
          <div class="agent-name">Solution AI</div>
          <div class="agent-status"><span class="pulse-dot me-1"></span>Always online</div>
        </div>
      </div>
      <div class="chat-actions">
        <button onclick="toggleDark()" title="Toggle theme"><i class="bi bi-moon-fill" id="darkIcon"></i></button>
        <button onclick="toggleChat()"><i class="bi bi-x-lg"></i></button>
      </div>
    </div>

    <!-- Messages -->
    <div id="chatMessages" class="chat-messages"></div>

    <!-- Quick Replies -->
    <div id="quickReplies" class="quick-replies">
      <button onclick="sendQuick('Tell me about your AI services')">🤖 AI Services</button>
      <button onclick="sendQuick('What are your pricing options?')">💰 Pricing</button>
      <button onclick="sendQuick('I want to book a free consultation')">📅 Consultation</button>
      <button onclick="sendQuick('Show me your portfolio')">📁 Portfolio</button>
      <button onclick="sendQuick('How do I contact your team?')">📞 Contact Us</button>
    </div>

    <!-- Input -->
    <div class="chat-input-area">
      <input type="text" id="chatInput" placeholder="Type your message..." onkeydown="if(event.key==='Enter')sendMessage()">
      <button onclick="sendMessage()" id="sendBtn"><i class="bi bi-send-fill"></i></button>
    </div>
    <div class="chat-footer">Powered by <strong>Solution AI</strong> · <a href="#" onclick="return false">Privacy</a></div>
  </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<style>
/* ===== CHATBOT STYLES ===== */
#chatWidget { position: fixed; bottom: 24px; right: 24px; z-index: 9999; }
#chatToggle {
  width: 60px; height: 60px; border-radius: 50%; border: none;
  background: var(--gradient); color: #fff; font-size: 1.4rem;
  cursor: pointer; box-shadow: 0 8px 30px rgba(108,99,255,0.5);
  transition: all 0.3s; position: relative;
}
#chatToggle:hover { transform: scale(1.1); }
.chat-badge {
  position: absolute; top: -4px; right: -4px; width: 20px; height: 20px;
  background: var(--accent); border-radius: 50%; font-size: 0.7rem;
  color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700;
}
#chatWindow {
  position: absolute; bottom: 75px; right: 0; width: 370px;
  background: #1A1D29; border: 1px solid rgba(255,255,255,0.08);
  border-radius: 20px; overflow: hidden;
  box-shadow: 0 20px 60px rgba(0,0,0,0.35);
  animation: slideUp 0.3s ease;
  color: #E2E8F0;
}
#chatWindow.light-mode { background: #fff; border-color: #e2e8f0; color: #1a202c; }
@keyframes slideUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
.chat-header {
  background: var(--gradient); padding: 16px 18px;
  display: flex; align-items: center; justify-content: space-between;
}
.chat-agent-info { display: flex; align-items: center; gap: 12px; }
.agent-avatar { width: 42px; height: 42px; border-radius: 50%; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-size: 1.2rem; color: #fff; }
.agent-name { font-weight: 700; color: #fff; font-size: 0.95rem; }
.agent-status { font-size: 0.75rem; color: rgba(255,255,255,0.8); display: flex; align-items: center; }
.chat-actions { display: flex; gap: 8px; }
.chat-actions button { background: rgba(255,255,255,0.2); border: none; color: #fff; width: 32px; height: 32px; border-radius: 8px; cursor: pointer; transition: all 0.2s; }
.chat-actions button:hover { background: rgba(255,255,255,0.3); }
.chat-messages { height: 350px; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 12px; scrollbar-width: thin; }
.msg-wrap { display: flex; gap: 8px; align-items: flex-end; }
.msg-wrap.user { flex-direction: row-reverse; }
.msg-avatar { width: 28px; height: 28px; border-radius: 50%; background: var(--gradient); display: flex; align-items: center; justify-content: center; font-size: 0.75rem; flex-shrink: 0; }
.msg-bubble { max-width: 78%; padding: 10px 14px; border-radius: 18px; font-size: 0.875rem; line-height: 1.5; }
.msg-wrap.assistant .msg-bubble { background: #2A2E3D; color: #e2e8f0; border-bottom-left-radius: 4px; }
.msg-wrap.user .msg-bubble { background: var(--gradient); color: #fff; border-bottom-right-radius: 4px; }
.msg-time { font-size: 0.68rem; color: #8A93A6; margin-top: 3px; }
.typing-bubble { display: flex; gap: 5px; padding: 12px 16px; background: #2A2E3D; border-radius: 18px; border-bottom-left-radius: 4px; width: fit-content; }
.typing-dot { width: 7px; height: 7px; border-radius: 50%; background: #8A93A6; animation: typingAnim 1.2s infinite; }
.typing-dot:nth-child(2){animation-delay:0.2s}
.typing-dot:nth-child(3){animation-delay:0.4s}
@keyframes typingAnim { 0%,60%,100%{transform:translateY(0)} 30%{transform:translateY(-6px)} }
.quick-replies { padding: 10px 12px; display: flex; flex-wrap: wrap; gap: 6px; border-top: 1px solid rgba(255,255,255,0.08); }
.quick-replies button { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: #E2E8F0; border-radius: 20px; padding: 5px 12px; font-size: 0.78rem; cursor: pointer; transition: all 0.2s; white-space: nowrap; }
.quick-replies button:hover { background: rgba(108,99,255,0.2); border-color: var(--primary); color: #fff; }
.chat-input-area { display: flex; padding: 12px; gap: 8px; border-top: 1px solid rgba(255,255,255,0.08); }
#chatInput { flex: 1; background: #2A2E3D; border: 1px solid rgba(255,255,255,0.1); border-radius: 25px; padding: 10px 16px; color: #fff; font-size: 0.88rem; outline: none; }
#chatInput:focus { border-color: var(--primary); }
#sendBtn { width: 42px; height: 42px; border-radius: 50%; border: none; background: var(--gradient); color: #fff; cursor: pointer; transition: all 0.2s; }
#sendBtn:hover { transform: scale(1.1); }
.chat-footer { text-align: center; font-size: 0.7rem; color: #8A93A6; padding: 6px; border-top: 1px solid rgba(255,255,255,0.08); }
.chat-footer a { color: var(--primary); text-decoration: none; }
#chatWindow.light-mode .msg-wrap.assistant .msg-bubble { background: #f1f5f9; color: #1a202c; }
#chatWindow.light-mode #chatInput { background: #f1f5f9; color: #1a202c; border-color: #e2e8f0; }
#chatWindow.light-mode .quick-replies button { background: #f1f5f9; border-color: #e2e8f0; color: #475569; }
@media (max-width: 480px) { #chatWindow { width: calc(100vw - 20px); right: -12px; } }
</style>

<script>
AOS.init({ duration: 700, once: true, offset: 80 });

// Navbar scroll effect
window.addEventListener('scroll', () => {
  const nav = document.getElementById('mainNav');
  nav.classList.toggle('scrolled', window.scrollY > 50);
  // Active link
  document.querySelectorAll('section[id]').forEach(s => {
    const top = s.offsetTop - 100, bot = top + s.offsetHeight;
    const link = document.querySelector(`.nav-link[href="#${s.id}"]`);
    if (link) link.classList.toggle('active', window.scrollY >= top && window.scrollY < bot);
  });
  // Back to top
  document.getElementById('backToTop').classList.toggle('show', window.scrollY > 300);
});

document.getElementById('backToTop').onclick = () => window.scrollTo({top:0,behavior:'smooth'});

// Contact Form
document.getElementById('contactForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  const btn = document.getElementById('submitBtn');
  const alert = document.getElementById('formAlert');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Submitting...';
  
  try {
    const res = await fetch('php/contact.php', { method: 'POST', body: new FormData(this) });
    const data = await res.json();
    alert.className = 'alert ' + (data.success ? 'alert-success' : 'alert-danger');
    alert.textContent = data.message;
    alert.classList.remove('d-none');
    if (data.success) this.reset();
  } catch {
    alert.className = 'alert alert-danger';
    alert.textContent = 'Network error. Please try again.';
    alert.classList.remove('d-none');
  }
  btn.disabled = false;
  btn.innerHTML = '<i class="bi bi-send-fill me-2"></i>Submit Inquiry';
  setTimeout(() => alert.classList.add('d-none'), 6000);
});

// ===== CHATBOT =====
let chatSessionId = null;
let chatOpen = false;
let isDark = true;
const welcomeMsg = "Hello! 👋 I'm your AI consultant at **Solution AI**. I'm here to help you discover how AI can transform your business.\n\nWhat can I help you with today?";

function toggleChat() {
  chatOpen = !chatOpen;
  const win = document.getElementById('chatWindow');
  const icon = document.getElementById('chatIcon');
  win.style.display = chatOpen ? 'block' : 'none';
  icon.className = chatOpen ? 'bi bi-x-lg' : 'bi bi-chat-dots-fill';
  document.getElementById('chatBadge').style.display = 'none';
  if (chatOpen && !chatSessionId) initChat();
}

async function initChat() {
  try {
    const res = await fetch('chatbot/php/chat.php', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({action:'start'})
    });
    const data = await res.json();
    if (data.success) {
      chatSessionId = data.session_id;
      appendMessage('assistant', welcomeMsg);
    }
  } catch { appendMessage('assistant', "Hello! 👋 I'm your AI consultant at Solution AI. How can I help you today?"); }
}

async function sendMessage() {
  const input = document.getElementById('chatInput');
  const msg = input.value.trim();
  if (!msg || !chatSessionId) return;
  input.value = '';
  appendMessage('user', msg);
  document.getElementById('quickReplies').style.display = 'none';
  showTyping();

  try {
    const res = await fetch('chatbot/php/chat.php', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({action:'message', session_id:chatSessionId, message:msg})
    });
    const data = await res.json();
    hideTyping();
    appendMessage('assistant', data.reply || "I'm sorry, I couldn't process that. Please try again.");
  } catch {
    hideTyping();
    appendMessage('assistant', "Sorry, I'm having trouble connecting. Please try again or use our Contact form.");
  }
}

function sendQuick(msg) {
  document.getElementById('chatInput').value = msg;
  sendMessage();
}

function appendMessage(role, text) {
  const container = document.getElementById('chatMessages');
  const wrap = document.createElement('div');
  wrap.className = 'msg-wrap ' + role;
  const time = new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
  const formatted = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
  wrap.innerHTML = `
    <div class="msg-avatar">${role==='assistant'?'<i class="bi bi-robot text-white"></i>':'<i class="bi bi-person text-white"></i>'}</div>
    <div>
      <div class="msg-bubble">${formatted}</div>
      <div class="msg-time">${time}</div>
    </div>`;
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
}

let typingEl = null;
function showTyping() {
  const container = document.getElementById('chatMessages');
  typingEl = document.createElement('div');
  typingEl.className = 'msg-wrap assistant';
  typingEl.id = 'typingIndicator';
  typingEl.innerHTML = `<div class="msg-avatar"><i class="bi bi-robot text-white"></i></div><div class="typing-bubble"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div>`;
  container.appendChild(typingEl);
  container.scrollTop = container.scrollHeight;
}
function hideTyping() { if (typingEl) { typingEl.remove(); typingEl = null; } }

function toggleDark() {
  isDark = !isDark;
  document.getElementById('chatWindow').classList.toggle('light-mode', !isDark);
  document.getElementById('darkIcon').className = isDark ? 'bi bi-moon-fill' : 'bi bi-sun-fill';
}

// Show badge after 3s
setTimeout(() => {
  if (!chatOpen) document.getElementById('chatBadge').style.display = 'flex';
}, 3000);
</script>
</body>
</html>
