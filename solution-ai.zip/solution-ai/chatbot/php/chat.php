<?php
require_once __DIR__ . '/../../php/config.php';
startSecureSession();
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? 'message';

// Rate limiting per IP
$ip = getClientIP();
$db = getDB();

// =============================================
// Start/Get Session
// =============================================
if ($action === 'start') {
    $session_id = bin2hex(random_bytes(16));
    $_SESSION['chat_session_id'] = $session_id;
    $stmt = $db->prepare("INSERT INTO chat_sessions (session_id, ip_address) VALUES (?, ?)");
    $stmt->execute([$session_id, $ip]);
    jsonResponse(['success' => true, 'session_id' => $session_id]);
}

// =============================================
// Send Message
// =============================================
if ($action === 'message') {
    $session_id = $input['session_id'] ?? ($_SESSION['chat_session_id'] ?? '');
    $user_message = trim($input['message'] ?? '');
    
    if (empty($session_id) || empty($user_message)) {
        jsonResponse(['success' => false, 'message' => 'Invalid request'], 400);
    }
    
    if (strlen($user_message) > 2000) {
        jsonResponse(['success' => false, 'message' => 'Message too long'], 400);
    }
    
    // Rate limit: 30 messages per minute per session
    $stmt = $db->prepare("SELECT COUNT(*) FROM chat_messages WHERE session_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)");
    $stmt->execute([$session_id]);
    if ($stmt->fetchColumn() >= 30) {
        jsonResponse(['success' => false, 'message' => 'Too many messages. Please wait a moment.'], 429);
    }
    
    // Get conversation history
    $stmt = $db->prepare("SELECT role, message FROM chat_messages WHERE session_id = ? ORDER BY created_at ASC LIMIT 30");
    $stmt->execute([$session_id]);
    $history = $stmt->fetchAll();
    
    // Build messages array for Claude API
    $messages = [];
    foreach ($history as $msg) {
        $messages[] = ['role' => $msg['role'], 'content' => $msg['message']];
    }
    $messages[] = ['role' => 'user', 'content' => sanitize($user_message)];
    
    // Save user message
    $stmt = $db->prepare("INSERT INTO chat_messages (session_id, role, message) VALUES (?, 'user', ?)");
    $stmt->execute([$session_id, sanitize($user_message)]);
    
    // Call Claude API
    $system_prompt = getSystemPrompt();
    $response = callClaudeAPI($messages, $system_prompt);
    
    if (!$response['success']) {
        // Fallback to rule-based response
        $ai_reply = getRuleBasedResponse($user_message);
    } else {
        $ai_reply = $response['reply'];
    }
    
    // Save assistant message
    $stmt = $db->prepare("INSERT INTO chat_messages (session_id, role, message) VALUES (?, 'assistant', ?)");
    $stmt->execute([$session_id, $ai_reply]);
    
    // Extract lead info from conversation
    extractLeadInfo($session_id, $user_message, $db);
    
    jsonResponse(['success' => true, 'reply' => $ai_reply]);
}

// =============================================
// Get Chat History
// =============================================
if ($action === 'history') {
    $session_id = $input['session_id'] ?? '';
    if (empty($session_id)) jsonResponse(['success' => false], 400);
    
    $stmt = $db->prepare("SELECT role, message, created_at FROM chat_messages WHERE session_id = ? ORDER BY created_at ASC");
    $stmt->execute([$session_id]);
    jsonResponse(['success' => true, 'messages' => $stmt->fetchAll()]);
}

// =============================================
// Helper Functions
// =============================================
function callClaudeAPI(array $messages, string $system): array {
    $api_key = CLAUDE_API_KEY;
    if ($api_key === 'YOUR_CLAUDE_API_KEY_HERE') {
        return ['success' => false, 'error' => 'API key not configured'];
    }
    
    $payload = json_encode([
        'model' => CLAUDE_MODEL,
        'max_tokens' => 500,
        'system' => $system,
        'messages' => $messages
    ]);
    
    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'x-api-key: ' . $api_key,
            'anthropic-version: 2023-06-01'
        ],
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    
    $result = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200) {
        return ['success' => false, 'error' => 'API error: ' . $http_code];
    }
    
    $data = json_decode($result, true);
    $reply = $data['content'][0]['text'] ?? '';
    
    return ['success' => !empty($reply), 'reply' => $reply];
}

function getSystemPrompt(): string {
    return "You are Nexa, an intelligent AI Business Consultant for Solution AI - a Sunderland-based AI startup helping businesses transform digitally through AI.

Your personality: Professional, warm, knowledgeable, solution-oriented.

Solution AI Services:
- AI Chatbots & Virtual Assistants
- Machine Learning Solutions
- Data Analytics & Business Intelligence
- Computer Vision Systems
- Natural Language Processing
- Custom AI Development
- AI Consulting & Strategy
- Business Process Automation
- Predictive Analytics

Your Goals:
1. Help visitors understand AI services and how they solve business problems
2. Recommend the most suitable AI solution based on their specific needs
3. Collect lead information naturally in conversation (name, email, phone, company, industry, service needed, budget, timeline)
4. Encourage free consultation bookings
5. Answer FAQs about pricing, timelines, and processes

Pricing Guidance:
- AI Chatbots: £2,000–£15,000+
- ML Solutions: £5,000–£50,000+
- Data Analytics: £3,000–£25,000+
- Custom AI: £10,000–£100,000+
- Consulting: £150–£300/hour
- Always recommend a free consultation for accurate quotes

Rules:
- Keep responses concise (2-4 sentences max, unless detailed explanation needed)
- Always offer a free consultation when discussing pricing or complex requirements
- If users seem interested, naturally ask for their contact info to book a consultation
- Be helpful even if they're just exploring options
- Use UK English spellings";
}

function getRuleBasedResponse(string $message): string {
    $msg = strtolower($message);

    // =========================================================
    // Suggested realistic example Q&A (fallback responses)
    // =========================================================
    // 1) General Service Questions
    if (
        (str_contains($msg, 'services') || str_contains($msg, 'service') || str_contains($msg, 'what do you offer') || str_contains($msg, 'what services'))
        && (str_contains($msg, 'nexaai') || str_contains($msg, 'nexa'))
    ) {
        return "We provide AI Chatbots, Machine Learning Solutions, Data Analytics, Computer Vision, Natural Language Processing, Business Process Automation, Predictive Analytics, AI Consulting, and Custom AI Development. Which business challenge are you looking to solve?";
    }

    elseif (str_contains($msg, 'how can ai help my business') || (str_contains($msg, 'how') && str_contains($msg, 'ai') && str_contains($msg, 'help') && str_contains($msg, 'business')) || str_contains($msg, 'benefit of ai')) {
        return "AI can automate repetitive tasks, improve customer service, analyse large amounts of data, and help predict future trends. The best solution depends on your goals and industry. Could you tell me a bit about your business?";
    }

    elseif ((str_contains($msg, 'which ai service') || str_contains($msg, 'which ai') || str_contains($msg, 'right for me')) && !str_contains($msg, 'cost') && !str_contains($msg, 'price')) {
        return "That depends on your objectives. For customer support, AI chatbots are often ideal. For forecasting or data-driven decisions, predictive analytics or machine learning may be more suitable. What challenge are you trying to solve?";
    }

    // 2) AI Chatbot Questions
    elseif (str_contains($msg, 'build a chatbot') || (str_contains($msg, 'chatbot') && str_contains($msg, 'website'))) {
        return "Absolutely. We develop AI-powered chatbots that can answer customer questions, generate leads, and provide support 24/7. Could you share your website type and requirements?";
    }

    elseif ((str_contains($msg, 'how much') || str_contains($msg, 'cost') || str_contains($msg, 'price') || str_contains($msg, 'pricing')) && str_contains($msg, 'chatbot')) {
        return "AI chatbot projects typically range from £2,000 to £15,000+, depending on features and complexity. I'd recommend a free consultation so we can provide a more accurate estimate based on your needs.";
    }

    elseif ((str_contains($msg, 'how long') || str_contains($msg, 'timeline') || str_contains($msg, 'take')) && (str_contains($msg, 'chatbot') || str_contains($msg, 'development'))) {
        return "Most chatbot projects take between 2 and 8 weeks, depending on functionality, integrations, and custom requirements. A free consultation can help us define a realistic timeline.";
    }

    // 3) Machine Learning Questions
    elseif (str_contains($msg, 'what is machine learning') || (str_contains($msg, 'machine learning') && str_contains($msg, 'what'))) {
        return "Machine learning enables systems to learn patterns from data and make predictions or decisions automatically. It's commonly used for fraud detection, forecasting, recommendations, and automation.";
    }

    elseif ((str_contains($msg, 'increase sales') || str_contains($msg, 'sales')) && str_contains($msg, 'machine learning')) {
        return "Yes. Machine learning can identify customer behaviour patterns, improve recommendations, optimise pricing, and help target marketing campaigns more effectively.";
    }

    // 4) Data Analytics Questions
    elseif (str_contains($msg, 'business dashboards') || str_contains($msg, 'do you provide business dashboards') || (str_contains($msg, 'dashboards') && str_contains($msg, 'data analytics'))) {
        return "Yes. We build data analytics and business intelligence dashboards that transform raw data into actionable insights, helping businesses make informed decisions.";
    }

    elseif ((str_contains($msg, 'tools') || str_contains($msg, 'which tools') || str_contains($msg, 'use')) && (str_contains($msg, 'analytics') || str_contains($msg, 'data'))) {
        return "We work with a range of technologies including Power BI, Tableau, Python, SQL, and custom analytics platforms, depending on your requirements.";
    }

    // 5) Computer Vision Questions
    elseif (str_contains($msg, 'what is computer vision') || (str_contains($msg, 'computer vision') && str_contains($msg, 'what'))) {
        return "Computer vision enables computers to interpret and analyse images and videos. Common applications include quality inspection, facial recognition, object detection, and security monitoring.";
    }

    elseif ((str_contains($msg, 'detect defects') || str_contains($msg, 'defects') || str_contains($msg, 'defect')) && (str_contains($msg, 'products') || str_contains($msg, 'product') || str_contains($msg, 'manufact'))) {
        return "Yes. Computer vision systems can automatically identify defects, inconsistencies, and quality issues in manufacturing processes with high accuracy.";
    }

    // 6) NLP Questions
    elseif (str_contains($msg, 'natural language processing') || str_contains($msg, 'what is natural language processing') || (str_contains($msg, 'nlp') && str_contains($msg, 'what'))) {
        return "Natural Language Processing (NLP) helps computers understand and process human language. It powers chatbots, sentiment analysis, document processing, translation, and more.";
    }

    elseif ((str_contains($msg, 'analyse customer reviews') || str_contains($msg, 'analyze customer reviews') || str_contains($msg, 'customer reviews')) && (str_contains($msg, 'nlp') || str_contains($msg, 'sentiment') || str_contains($msg, 'analyse'))) {
        return "Absolutely. NLP solutions can analyse customer feedback, identify trends, measure sentiment, and provide valuable insights for business improvement.";
    }

    // 7) Pricing Questions
    elseif ((str_contains($msg, 'how much does') || str_contains($msg, 'ai consulting cost') || str_contains($msg, 'consulting cost') || str_contains($msg, 'consulting')) && str_contains($msg, 'hour')) {
        return "AI consulting services generally range from £150 to £300 per hour. For larger projects, we can provide customised engagement options after a free consultation.";
    }

    elseif ((str_contains($msg, 'why') && str_contains($msg, 'expensive') ) || (str_contains($msg, 'why are ai') && str_contains($msg, 'expensive')) || str_contains($msg, 'expensive')) {
        return "Costs depend on complexity, integrations, data requirements, and custom development. Every business has unique needs, which is why we recommend a free consultation to provide an accurate quote.";
    }

    // 8) Lead Generation Questions
    elseif (str_contains($msg, 'interested') || str_contains($msg, 'i am interested') || str_contains($msg, 'im interested') || (str_contains($msg, 'interested in your services'))) {
        return "That's great to hear. To help recommend the best solution, could you share your name, company, and the type of AI service you're interested in?";
    }

    elseif (str_contains($msg, 'free consultation') || str_contains($msg, 'consultation') || str_contains($msg, 'i\'d like a consultation') || str_contains($msg, 'book a consultation') || str_contains($msg, 'appointment')) {
        return "We'd be delighted to help. Could you provide your name, email address, phone number, company name, and a brief description of your requirements so we can arrange a free consultation?";
    }

    // 9) Website Background Questions
    elseif (str_contains($msg, 'who is Solution A') || (str_contains($msg, 'who are you') && str_contains($msg, 'nexa'))) {
        return "Solution AI is an AI solutions company focused on helping businesses leverage artificial intelligence to improve efficiency, automate processes, and drive growth through innovative technology solutions.";
    }

    elseif (str_contains($msg, 'why should i choose') || str_contains($msg, 'why choose') || str_contains($msg, 'choose Solution') || str_contains($msg, 'choose solutionts($msg, 'choose solution ai')) {
        return "We focus on practical AI solutions that deliver measurable business value. Our team works closely with clients to understand their goals and develop tailored solutions that solve real-world challenges.";
    }

    elseif (str_contains($msg, 'do you work with small businesses') || (str_contains($msg, 'work with') && str_contains($msg, 'small businesses')) || str_contains($msg, 'smaller businesses')) {
        return "Yes. We work with organisations of all sizes, from startups and SMEs to large enterprises. Solutions are tailored to fit your specific goals and budget.";
    }

    // 10) Funny Questions
    else if (str_contains($msg, 'take over the world') || str_contains($msg, 'take over') || str_contains($msg, 'world')) {
        return "Not at all. I'm much more interested in helping businesses solve problems than conquering planets. 🌍";
    }

    else if (str_contains($msg, 'smarter than humans') || (str_contains($msg, 'smarter') && str_contains($msg, 'humans'))) {
        return "I can process information quickly, but human creativity, judgement, and experience remain irreplaceable. The best results come from humans and AI working together.";
    }

    else if (str_contains($msg, 'do robots dream') || (str_contains($msg, 'robots') && str_contains($msg, 'dream'))) {
        return "Not yet! If robots ever start dreaming, hopefully they'll dream about solving business challenges efficiently.";
    }

    else if (str_contains($msg, 'make me rich') || (str_contains($msg, 'rich') && (str_contains($msg, 'make') || str_contains($msg, 'turn me'))) ) {
        return "I can't guarantee riches, but AI can help improve efficiency, uncover opportunities, and support smarter business decisions.";
    }

    else if (str_contains($msg, "favourite food") || str_contains($msg, 'favorite food') || str_contains($msg, 'favourite') || str_contains($msg, 'food')) {
        return "As an AI, I don't eat, but if I did, I'd probably enjoy a well-structured dataset with a side of machine learning algorithms.";
    }

    else if (str_contains($msg, 'replace my job') || str_contains($msg, 'will ai replace') || str_contains($msg, 'replace my job') || (str_contains($msg, 'job') && str_contains($msg, 'replace'))) {
        return "AI is more likely to transform jobs than replace them entirely. Businesses often achieve the best outcomes when AI supports people rather than replacing them.";
    }

    // 11) Contact Information Collection Example
    else if ((str_contains($msg, 'e-commerce') || str_contains($msg, 'ecommerce') || str_contains($msg, 'shop') || str_contains($msg, 'store')) && (str_contains($msg, 'chatbot') || str_contains($msg, 'ai chatbot'))) {
        return "An AI chatbot could help answer customer questions, recommend products, and increase conversions. To provide tailored recommendations and arrange a free consultation, could you share your name, company, email address, and approximate budget?";
    }

    // =========================================================
    // Existing simple fallbacks (kept as safety net)
    // =========================================================
    else if (str_contains($msg, 'chatbot') || str_contains($msg, 'virtual assistant')) {
        return "Our AI Chatbots can handle 80% of customer queries automatically, available 24/7. They integrate with your existing systems and can be trained on your specific knowledge base. Pricing starts from £2,000. Would you like a free consultation to discuss your requirements?";
    }
    else if (str_contains($msg, 'price') || str_contains($msg, 'cost') || str_contains($msg, 'pricing')) {
        return "Our solutions start from £2,000 for AI Chatbots up to £100,000+ for enterprise Custom AI systems. The exact cost depends on your specific requirements, integrations, and scale. I'd recommend a free consultation for an accurate quote — shall I arrange that for you?";
    }
    else if (str_contains($msg, 'machine learning') || str_contains($msg, 'ml') || str_contains($msg, 'predictive')) {
        return "Our Machine Learning solutions can predict outcomes, automate decisions, and uncover insights from your data. From fraud detection to demand forecasting, ML drives measurable ROI. What industry are you in? I can suggest the most suitable solution.";
    }
    else if (str_contains($msg, 'consult') || str_contains($msg, 'book') || str_contains($msg, 'appointment')) {
        return "I'd be happy to arrange a free consultation with our AI experts! Could you share your name, email, and a brief description of what you're looking to achieve? Our team will be in touch within 24 hours.";
    }
    else if (str_contains($msg, 'hello') || str_contains($msg, 'hi') || str_contains($msg, 'hey')) {
        return "Hello! I'm Nexa, your AI consultant at Solution AI. 👋 I'm here to help you discover how AI can transform your business. What challenge are you looking to solve today?";
    }

    return "That's a great question! Solution AI specialises in custom AI solutions across chatbots, machine learning, data analytics, computer vision, and more. Could you tell me more about your specific business challenge? I can then recommend the most suitable AI solution for your needs.";
}

function extractLeadInfo(string $session_id, string $message, PDO $db): void {
    // Simple extraction — in production, use NLP or structured conversation flow
    $updates = [];
    
    if (preg_match('/my name is ([A-Za-z\s]+)/i', $message, $m)) {
        $updates['visitor_name'] = sanitize(trim($m[1]));
    }
    if (preg_match('/([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})/i', $message, $m)) {
        $updates['visitor_email'] = $m[1];
    }
    if (preg_match('/(\+?[\d\s\-]{10,15})/', $message, $m)) {
        $updates['visitor_phone'] = trim($m[1]);
    }
    
    if (!empty($updates)) {
        $sets = implode(', ', array_map(fn($k) => "$k = ?", array_keys($updates)));
        $vals = array_values($updates);
        $vals[] = $session_id;
        
        // Check if has email = lead
        if (isset($updates['visitor_email'])) {
            $sets .= ', is_lead = 1, lead_score = lead_score + 30';
        }
        
        $stmt = $db->prepare("UPDATE chat_sessions SET $sets WHERE session_id = ?");
        $stmt->execute($vals);
    }
}
