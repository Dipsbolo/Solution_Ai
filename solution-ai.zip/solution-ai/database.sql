-- =============================================
-- Solution AI - Database Schema
-- =============================================

CREATE DATABASE IF NOT EXISTS solution_ai CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE solution_ai;

-- Admin Users Table
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(150),
    role ENUM('superadmin','admin') DEFAULT 'admin',
    reset_token VARCHAR(255) DEFAULT NULL,
    reset_expires DATETIME DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Contact Inquiries Table
CREATE TABLE IF NOT EXISTS contact_inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(30),
    company_name VARCHAR(200),
    country VARCHAR(100),
    job_title VARCHAR(150),
    job_details TEXT,
    status ENUM('new','read','replied','archived') DEFAULT 'new',
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Services Table
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    icon VARCHAR(100),
    is_active TINYINT(1) DEFAULT 1,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Chat Sessions Table
CREATE TABLE IF NOT EXISTS chat_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL UNIQUE,
    visitor_name VARCHAR(150),
    visitor_email VARCHAR(150),
    visitor_phone VARCHAR(30),
    company_name VARCHAR(200),
    industry VARCHAR(150),
    required_service VARCHAR(200),
    budget VARCHAR(100),
    timeline VARCHAR(100),
    requirements TEXT,
    lead_score INT DEFAULT 0,
    is_lead TINYINT(1) DEFAULT 0,
    status ENUM('active','closed') DEFAULT 'active',
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at DATETIME DEFAULT NULL,
    ip_address VARCHAR(45)
);

-- Chat Messages Table
CREATE TABLE IF NOT EXISTS chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    role ENUM('user','assistant') NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session (session_id)
);

-- Chat Analytics Table
CREATE TABLE IF NOT EXISTS chat_analytics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date DATE NOT NULL UNIQUE,
    total_sessions INT DEFAULT 0,
    leads_generated INT DEFAULT 0,
    avg_duration_minutes DECIMAL(5,2) DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default admin user (password: Admin@123)
INSERT INTO admin_users (username, email, password, full_name, role) VALUES 
('admin', 'admin@solution-ai.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Super Admin', 'superadmin')
ON DUPLICATE KEY UPDATE id=id;

-- Insert default services
INSERT INTO services (title, description, icon, sort_order) VALUES
('AI Chatbots', 'Intelligent conversational AI to automate customer support and engagement 24/7.', 'bi-chat-dots', 1),
('Machine Learning', 'Custom ML models for predictive analytics and intelligent automation.', 'bi-cpu', 2),
('Data Analytics', 'Transform raw data into actionable business insights with AI-powered dashboards.', 'bi-bar-chart-line', 3),
('Computer Vision', 'Image and video analysis solutions for quality control and security.', 'bi-eye', 4),
('NLP Solutions', 'Natural Language Processing for sentiment analysis, text mining, and more.', 'bi-translate', 5),
('AI Consulting', 'Strategic AI roadmap and implementation consulting for digital transformation.', 'bi-lightbulb', 6),
('Process Automation', 'Automate repetitive business workflows with intelligent RPA solutions.', 'bi-gear', 7),
('Predictive Analytics', 'Forecast trends and outcomes using advanced statistical AI models.', 'bi-graph-up-arrow', 8)
ON DUPLICATE KEY UPDATE id=id;
