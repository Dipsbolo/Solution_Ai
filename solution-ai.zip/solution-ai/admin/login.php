<?php
require_once __DIR__ . '/../php/config.php';
startSecureSession();

// Already logged in
if (!empty($_SESSION['admin_id'])) {
    header('Location: index.php'); exit;
}

$error = '';
$success = '';
$csrf = generateCsrf();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrf($_POST['csrf_token'] ?? '')) {
        $error = 'Security token mismatch. Please refresh.';
    } else {
        $username = sanitize($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $error = 'Username and password are required.';
        } else {
            $db = getDB();
            // Lockout check
            $lockKey = 'login_fails_' . md5(getClientIP());
            $fails = $_SESSION[$lockKey] ?? 0;
            $lockTime = $_SESSION[$lockKey . '_time'] ?? 0;
            
            if ($fails >= MAX_LOGIN_ATTEMPTS && (time() - $lockTime) < LOCKOUT_TIME) {
                $remaining = ceil((LOCKOUT_TIME - (time() - $lockTime)) / 60);
                $error = "Too many failed attempts. Try again in {$remaining} minute(s).";
            } else {
                $stmt = $db->prepare("SELECT * FROM admin_users WHERE username = ? OR email = ?");
                $stmt->execute([$username, $username]);
                $admin = $stmt->fetch();
                
                if ($admin && password_verify($password, $admin['password'])) {
                    $_SESSION['admin_id'] = $admin['id'];
                    $_SESSION['admin_name'] = $admin['full_name'];
                    $_SESSION['admin_role'] = $admin['role'];
                    $_SESSION[$lockKey] = 0;
                    session_regenerate_id(true);
                    $db->prepare("UPDATE admin_users SET last_login = NOW() WHERE id = ?")->execute([$admin['id']]);
                    header('Location: index.php'); exit;
                } else {
                    $_SESSION[$lockKey] = $fails + 1;
                    $_SESSION[$lockKey . '_time'] = time();
                    $error = 'Invalid username or password.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login | Solution AI</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
:root { --primary:#6C63FF; --gradient:linear-gradient(135deg,#6C63FF,#00D4FF); }
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#F7F8FA; min-height:100vh; display:flex; align-items:center; justify-content:center; position:relative; overflow:hidden; }
.bg-glow { position:fixed; inset:0; background:radial-gradient(ellipse at 30% 50%,hsla(240, 12%, 88%, 1),transparent 60%),radial-gradient(ellipse at 70% 30%,rgba(0,212,255,0.08),transparent 60%); pointer-events:none; }
.login-card { background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,1); border-radius:24px; padding:48px 40px; width:100%; max-width:420px; backdrop-filter:blur(20px); box-shadow:0 20px 60px rgba(0,0,0,0.4); }
.brand { text-align:center; margin-bottom:32px; }
.brand-logo { font-size:2rem; font-weight:900; background:var(--gradient); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
.brand-sub { color:#64748B; font-size:0.85rem; margin-top:4px; }
.form-control { background:rgba(255,255,255,0.05) !important; border: 1.5px solid #4A90E2 !important;; color:#000000 !important; border-radius:12px !important; padding:12px 16px !important; }
.form-control:focus { border-color:var(--primary) !important; box-shadow:0 0 0 3px rgba(108,99,255,0.2) !important; background:rgba(255,255,255,0.08) !important; }
.form-control::placeholder { color:#64748B !important; }
.form-label { color:#000000; font-size:0.88rem; font-weight:600; }
.input-group .btn { background:transparent; border:1px solid rgba(255,255,255,0.08); border-left: none !important;; color:#64748B; border-radius:0 12px 12px 0 !important; }
.input-group .form-control { border-right:none !important; border-radius:12px 0 0 12px !important; }
.btn-login { background:var(--gradient); border:none; color:#fff; font-weight:700; padding:14px; border-radius:12px; font-size:1rem; width:100%; transition:all 0.3s; }
.btn-login:hover { opacity:0.9; transform:translateY(-2px); }
.divider { border-color:rgba(255,255,255,0.08); }
.back-link { color:#64748B; font-size:0.85rem; text-decoration:none; display:flex; align-items:center; gap:6px; }
.back-link:hover { color:var(--primary); }
.default-creds { background:rgba(108,99,255,0.08); border:1px solid rgba(108,99,255,0.2); border-radius:12px; padding:14px; margin-bottom:24px; font-size:0.8rem; color:#94A3B8; }
</style>
</head>
<body>
<div class="bg-glow"></div>
<div class="login-card">
  <div class="brand">
    <div class="brand-logo"><i class="bi bi-hexagon-fill me-1"></i>Solution AI</div>
    <div class="brand-sub">Admin Control Panel</div>
  </div>

 

  <?php if ($error): ?>
  <div class="alert alert-danger d-flex align-items-center gap-2 mb-4" style="border-radius:12px;background:rgba(239,68,68,0.1);border-color:rgba(239,68,68,0.3);color:#FCA5A5">
    <i class="bi bi-exclamation-triangle-fill"></i><?= $error ?>
  </div>
  <?php endif; ?>

  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
    <div class="mb-3">
      <label class="form-label">Username or Email</label>
      <input type="text" class="form-control" name="username" placeholder="admin" autocomplete="username" required>
    </div>
    <div class="mb-4">
      <label class="form-label">Password</label>
      <div class="input-group">
        <input type="password" class="form-control" name="password" id="passInput" placeholder="••••••••" autocomplete="current-password" required>
        <button type="button" class="btn" onclick="togglePass()"><i class="bi bi-eye" id="eyeIcon"></i></button>
      </div>
    </div>
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" id="remember" style="accent-color:var(--primary)">
        <label class="form-check-label text-muted small" for="remember">Remember me</label>
      </div>
      <a href="forgot-password.php" class="text-decoration-none" style="color:var(--primary);font-size:0.85rem">Forgot password?</a>
    </div>
    <button type="submit" class="btn-login">
      <i class="bi bi-shield-lock-fill me-2"></i>Sign In to Dashboard
    </button>
  </form>
  <hr class="divider my-4">
  <div class="text-center">
    <a href="../index.php" class="back-link justify-content-center"><i class="bi bi-arrow-left"></i>Back to Website</a>
  </div>
</div>
<script>
function togglePass() {
  const i = document.getElementById('passInput');
  const e = document.getElementById('eyeIcon');
  i.type = i.type === 'password' ? 'text' : 'password';
  e.className = i.type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
}
</script>
</body>
</html>
