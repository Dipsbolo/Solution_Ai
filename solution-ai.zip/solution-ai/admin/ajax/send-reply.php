<?php
require_once __DIR__ . '/../../php/config.php';
requireAuth();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../../vendor/phpmailer/phpmailer/src/Exception.php';
require_once __DIR__ . '/../../vendor/phpmailer/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/../../vendor/phpmailer/phpmailer/src/SMTP.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    jsonResponse(['success' => false, 'message' => 'Invalid request data'], 400);
}

$id      = (int)($data['id'] ?? 0);
$message = trim($data['message'] ?? '');

if (!$id || empty($message)) {
    jsonResponse(['success' => false, 'message' => 'Inquiry ID and message are required'], 400);
}

// Fetch inquiry from DB
$db   = getDB();
$stmt = $db->prepare("SELECT * FROM contact_inquiries WHERE id = ?");
$stmt->execute([$id]);
$inq = $stmt->fetch();

if (!$inq) {
    jsonResponse(['success' => false, 'message' => 'Inquiry not found'], 404);
}

// Build professional HTML email body
$adminName  = htmlspecialchars($_SESSION['admin_name'] ?? 'Solution AI Team');
$clientName = htmlspecialchars($inq['name']);
$clientEmail = $inq['email'];
$jobTitle   = htmlspecialchars($inq['job_title']);
$company    = htmlspecialchars($inq['company_name']);
$msgEscaped = nl2br(htmlspecialchars($message));

$htmlBody = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reply from Solution AI</title>
</head>
<body style="margin:0;padding:0;background:#F1F3F6;font-family:'Segoe UI',Arial,sans-serif;">

  <!-- Wrapper -->
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#F1F3F6;padding:40px 0;">
    <tr>
      <td align="center">
        <table width="620" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(17,24,39,0.10);">

          <!-- Header -->
          <tr>
            <td style="background:linear-gradient(135deg,#6C63FF,#00D4FF);padding:36px 40px 30px;text-align:center;">
              <div style="width:52px;height:52px;background:rgba(255,255,255,0.2);border-radius:14px;display:inline-flex;align-items:center;justify-content:center;margin-bottom:14px;">
                <span style="font-size:26px;line-height:52px;">&#10022;</span>
              </div>
              <h1 style="color:#ffffff;font-size:22px;font-weight:800;margin:0 0 6px;">Solution AI</h1>
              <p style="color:rgba(255,255,255,0.85);font-size:13px;margin:0;letter-spacing:1px;text-transform:uppercase;">Official Response to Your Inquiry</p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding:36px 40px 24px;">
              <p style="color:#6B7280;font-size:14px;margin:0 0 6px;">Dear <strong style="color:#2A2F3A;">{$clientName}</strong>,</p>
              <p style="color:#6B7280;font-size:14px;margin:0 0 28px;">
                Thank you for reaching out to <strong>Solution AI</strong>. We have reviewed your inquiry and our team is pleased to respond below.
              </p>

              <!-- Reply Box -->
              <div style="background:#F8F9FF;border-left:4px solid #6C63FF;border-radius:0 12px 12px 0;padding:24px 28px;margin-bottom:28px;">
                <p style="color:#9098A8;font-size:11px;text-transform:uppercase;letter-spacing:1.5px;margin:0 0 12px;font-weight:700;">Our Response</p>
                <div style="color:#2A2F3A;font-size:15px;line-height:1.8;">{$msgEscaped}</div>
              </div>

              <!-- Inquiry Reference -->
              <div style="background:#F1F3F6;border-radius:10px;padding:16px 20px;margin-bottom:28px;">
                <p style="color:#9098A8;font-size:11px;text-transform:uppercase;letter-spacing:1.5px;margin:0 0 10px;font-weight:700;">Your Inquiry Reference</p>
                <table cellpadding="0" cellspacing="0" width="100%">
                  <tr>
                    <td style="color:#6B7280;font-size:13px;padding:3px 0;width:110px;">Inquiry ID</td>
                    <td style="color:#2A2F3A;font-size:13px;font-weight:600;padding:3px 0;">#INQ-{$inq['id']}</td>
                  </tr>
                  <tr>
                    <td style="color:#6B7280;font-size:13px;padding:3px 0;">Company</td>
                    <td style="color:#2A2F3A;font-size:13px;font-weight:600;padding:3px 0;">{$company}</td>
                  </tr>
                  <tr>
                    <td style="color:#6B7280;font-size:13px;padding:3px 0;">Role</td>
                    <td style="color:#2A2F3A;font-size:13px;font-weight:600;padding:3px 0;">{$jobTitle}</td>
                  </tr>
                </table>
              </div>

              <p style="color:#6B7280;font-size:14px;line-height:1.7;margin:0 0 8px;">
                If you have any further questions or wish to discuss your requirements in detail, please do not hesitate to reply to this email or reach out to our team directly.
              </p>
              <p style="color:#6B7280;font-size:14px;margin:0;">
                We look forward to working with you.
              </p>
            </td>
          </tr>

          <!-- Signature -->
          <tr>
            <td style="padding:0 40px 36px;">
              <table cellpadding="0" cellspacing="0">
                <tr>
                  <td style="padding-right:14px;vertical-align:middle;">
                    <div style="width:44px;height:44px;background:linear-gradient(135deg,#6C63FF,#00D4FF);border-radius:50%;text-align:center;line-height:44px;color:#fff;font-weight:800;font-size:16px;">
                      {$adminName[0]}
                    </div>
                  </td>
                  <td style="vertical-align:middle;">
                    <p style="margin:0;font-weight:700;color:#2A2F3A;font-size:14px;">{$adminName}</p>
                    <p style="margin:0;color:#6C63FF;font-size:12px;">Solution AI Team</p>
                    <p style="margin:4px 0 0;color:#9098A8;font-size:11px;">deepak.sah.450045@gmail.com</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Divider -->
          <tr>
            <td style="padding:0 40px;">
              <hr style="border:none;border-top:1px solid #E8EAEF;margin:0;">
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding:24px 40px;text-align:center;">
              <p style="color:#B0B7C3;font-size:12px;margin:0 0 6px;">
                &copy; <?= date('Y') ?> Solution AI. All rights reserved.
              </p>
              <p style="color:#B0B7C3;font-size:11px;margin:0;">
                This email is in response to the inquiry submitted through the Solution AI website.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>

</body>
</html>
HTML;

// Plain text fallback
$plainBody = "Dear {$clientName},\n\nThank you for contacting Solution AI.\n\nOur Response:\n{$message}\n\nInquiry Reference: #INQ-{$inq['id']}\nCompany: {$company}\nRole: {$jobTitle}\n\nIf you have further questions, please reply to this email.\n\nBest regards,\n{$adminName}\nSolution AI Team\ndeepak.sah.450045@gmail.com";

// Send via PHPMailer
try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = MAIL_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = MAIL_USERNAME;
    $mail->Password   = MAIL_PASSWORD;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = MAIL_PORT;

    $mail->setFrom(MAIL_USERNAME, MAIL_FROM_NAME);
    $mail->addAddress($clientEmail, $clientName);
    $mail->addReplyTo(MAIL_USERNAME, MAIL_FROM_NAME);

    $mail->isHTML(true);
    $mail->Subject = "Re: Your Inquiry to Solution AI — Ref #INQ-{$inq['id']}";
    $mail->Body    = $htmlBody;
    $mail->AltBody = $plainBody;

    $mail->send();

    // Update inquiry status to 'replied'
    $db->prepare("UPDATE contact_inquiries SET status='replied', updated_at=NOW() WHERE id=?")->execute([$id]);

    jsonResponse(['success' => true, 'message' => 'Reply sent successfully to ' . $clientEmail]);
} catch (Exception $e) {
    jsonResponse(['success' => false, 'message' => 'Email could not be sent. Error: ' . $mail->ErrorInfo], 500);
}
