<?php
require_once __DIR__ . '/../../php/config.php';
requireAuth();
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
$id = (int)($input['id'] ?? 0);
if (!$id) { jsonResponse(['success'=>false,'message'=>'Invalid ID'], 400); }
$db = getDB();
$db->prepare("DELETE FROM contact_inquiries WHERE id=?")->execute([$id]);
jsonResponse(['success'=>true]);
