<?php
require_once __DIR__ . '/../../php/config.php';
requireAuth();
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
$id = (int)($input['id'] ?? 0);
$status = $input['status'] ?? '';
$allowed = ['new','read','replied','archived'];
if (!$id || !in_array($status, $allowed)) { jsonResponse(['success'=>false,'message'=>'Invalid input'], 400); }
$db = getDB();
$stmt = $db->prepare("UPDATE contact_inquiries SET status=? WHERE id=?");
$stmt->execute([$status, $id]);
jsonResponse(['success'=>true]);
