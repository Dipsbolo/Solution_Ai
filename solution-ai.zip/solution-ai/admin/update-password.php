<?php
require_once __DIR__ . '/../php/config.php';
requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
if (!validateCsrf($_POST['csrf_token'] ?? '')) { header('Location: index.php?msg=csrf_error'); exit; }

$current = $_POST['current_password'] ?? '';
$new = $_POST['new_password'] ?? '';
$confirm = $_POST['confirm_password'] ?? '';

if (empty($current) || empty($new) || empty($confirm)) { header('Location: index.php?page=settings&msg=fields_required'); exit; }
if ($new !== $confirm) { header('Location: index.php?page=settings&msg=password_mismatch'); exit; }
if (strlen($new) < 8) { header('Location: index.php?page=settings&msg=password_short'); exit; }

$db = getDB();
$stmt = $db->prepare("SELECT password FROM admin_users WHERE id=?");
$stmt->execute([$_SESSION['admin_id']]);
$admin = $stmt->fetch();

if (!$admin || !password_verify($current, $admin['password'])) {
    header('Location: index.php?page=settings&msg=wrong_password'); exit;
}

$hash = password_hash($new, PASSWORD_BCRYPT, ['cost' => 12]);
$db->prepare("UPDATE admin_users SET password=? WHERE id=?")->execute([$hash, $_SESSION['admin_id']]);
header('Location: index.php?page=settings&msg=password_updated');
exit;
