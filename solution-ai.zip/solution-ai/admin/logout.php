<?php
require_once __DIR__ . '/../php/config.php';
startSecureSession();
session_destroy();
header('Location: login.php');
exit;
