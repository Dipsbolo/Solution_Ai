<?php
require_once __DIR__ . '/../php/config.php';
startSecureSession();
if (!empty($_SESSION['admin_id'])) { header('Location: index.php'); exit; }
$csrf = generateCsrf();
$msg = ''; $msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrf($_POST['csrf_token'] ?? '')) { $msg = 'Security error.'; $msgType = 'danger'; }
    else {
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
        if (!$email) { $msg = 'Please enter a valid email address.'; $msgType = 'danger'; }
        else {
            $db = getDB();
            $stmt = $db->prepare("SELECT id FROM admin_users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', time() + 3600);
                $db->prepare("UPDATE admin_users SET reset_token=?, reset_expires=? WHERE email=?")->execute([$token, $expires, $email]);
                // In production, send email with reset link
                $msg = 'If this email exists, a reset link has been sent. Check your inbox.';
            } else {
                $msg = 'If this email exists, a reset link has been sent. Check your inbox.';
            }
            $msgType = 'success';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password | Solution AI Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
:root{--primary:#6C63FF;--gradient:linear-gradient(135deg,#6C63FF,#00D4FF)}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Inter',sans-serif;background:#0A0E1A;min-height:100vh;display:flex;align-items:center;justify-content:center}
.bg-glow{position:fixed;inset:0;background:radial-gradient(ellipse at 30% 50%,rgba(108,99,255,0.12),transparent 60%);pointer-events:none}
.card{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:24px;padding:48px 40px;width:100%;max-width:420px;backdrop-filter:blur(20px)}
.brand{text-align:center;margin-bottom:32px}
.brand-logo{font-size:1.8rem;font-weight:900;background:var(--gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.brand-sub{color:#64748B;font-size:0.85rem;margin-top:4px}
.form-control{background:rgba(255,255,255,0.05)!important;border:1px solid rgba(255,255,255,0.08)!important;color:#fff!important;border-radius:12px!important;padding:12px 16px!important}
.form-control:focus{border-color:var(--primary)!important;box-shadow:0 0 0 3px rgba(108,99,255,0.2)!important}
.form-control::placeholder{color:#64748B!important}
.form-label{color:#CBD5E1;font-size:0.88rem;font-weight:600}
.btn-submit{background:var(--gradient);border:none;color:#fff;font-weight:700;padding:13px;border-radius:12px;width:100%;font-size:1rem}
</style>
</head>
<body>
<div class="bg-glow"></div>
<div class="card">
  <div class="brand">
    <div class="brand-logo"><i class="bi bi-hexagon-fill me-1"></i>Solution AI</div>
    <div class="brand-sub">Reset Your Password</div>
  </div>
  <?php if ($msg): ?>
  <div class="alert alert-<?= $msgType ?> mb-4" style="border-radius:12px;background:rgba(<?= $msgType==='success'?'34,197,94':'239,68,68' ?>,0.1);border-color:rgba(<?= $msgType==='success'?'34,197,94':'239,68,68' ?>,0.3);color:<?= $msgType==='success'?'#86efac':'#fca5a5' ?>">
    <?= $msg ?>
  </div>
  <?php endif; ?>
  <p style="color:#64748B;font-size:0.88rem;margin-bottom:24px">Enter your admin email address and we'll send you a password reset link.</p>
  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
    <div class="mb-4">
      <label class="form-label">Admin Email Address</label>
      <input type="email" class="form-control" name="email" placeholder="admin@solution-ai.com" required>
    </div>
    <button type="submit" class="btn-submit"><i class="bi bi-send me-2"></i>Send Reset Link</button>
  </form>
  <div class="text-center mt-4">
    <a href="login.php" style="color:#6C63FF;font-size:0.85rem;text-decoration:none"><i class="bi bi-arrow-left me-1"></i>Back to Login</a>
  </div>
</div>
</body>
</html>
