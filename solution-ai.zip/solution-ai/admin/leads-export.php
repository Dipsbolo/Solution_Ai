<?php
require_once __DIR__ . '/../php/config.php';
requireAuth();

$db = getDB();
$rows = $db->query("SELECT id, visitor_name, visitor_email, visitor_phone, company_name, industry, required_service, budget, timeline, requirements, lead_score, started_at FROM chat_sessions WHERE is_lead=1 ORDER BY started_at DESC")->fetchAll();

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="solution-ai-leads-' . date('Y-m-d') . '.csv"');
header('Pragma: no-cache');

$out = fopen('php://output', 'w');
fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
fputcsv($out, ['ID','Name','Email','Phone','Company','Industry','Required Service','Budget','Timeline','Requirements','Lead Score','Date']);
foreach ($rows as $row) { fputcsv($out, $row); }
fclose($out);
exit;
