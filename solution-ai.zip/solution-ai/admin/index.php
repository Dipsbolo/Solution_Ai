<?php
require_once __DIR__ . '/../php/config.php';
requireAuth();

$db = getDB();
$adminName = $_SESSION['admin_name'] ?? 'Admin';

// ===== ANALYTICS DATA =====
// Total inquiries
$totalInquiries = $db->query("SELECT COUNT(*) FROM contact_inquiries")->fetchColumn();
$newInquiries = $db->query("SELECT COUNT(*) FROM contact_inquiries WHERE status='new'")->fetchColumn();
$totalServices = $db->query("SELECT COUNT(*) FROM services WHERE is_active=1")->fetchColumn();
$todayInquiries = $db->query("SELECT COUNT(*) FROM contact_inquiries WHERE DATE(created_at)=CURDATE()")->fetchColumn();

// Monthly inquiries (last 6 months)
$monthlyData = $db->query("
    SELECT DATE_FORMAT(created_at,'%b %Y') as month, COUNT(*) as count
    FROM contact_inquiries
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY YEAR(created_at), MONTH(created_at)
    ORDER BY created_at ASC
")->fetchAll();

// Country distribution
$countryData = $db->query("
    SELECT country, COUNT(*) as count FROM contact_inquiries WHERE country != '' GROUP BY country ORDER BY count DESC LIMIT 8
")->fetchAll();

// Recent inquiries
$recentInquiries = $db->query("
    SELECT * FROM contact_inquiries ORDER BY created_at DESC LIMIT 10
")->fetchAll();

// Chat analytics
$totalChats = $db->query("SELECT COUNT(*) FROM chat_sessions")->fetchColumn();
$totalLeads = $db->query("SELECT COUNT(*) FROM chat_sessions WHERE is_lead=1")->fetchColumn();

// Status breakdown
$statusData = $db->query("SELECT status, COUNT(*) as count FROM contact_inquiries GROUP BY status")->fetchAll();
$statusMap = array_column($statusData, 'count', 'status');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard | Solution AI</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
:root {
  --primary:#6C63FF; --primary-dark:#4B44CC; --secondary:#00A8CC; --accent:#FF6584;
  --sidebar-bg:#3F4654; --main-bg:#F1F3F6; --card-bg:#FFFFFF;
  --border:rgba(17,24,39,0.08); --text:#2A2F3A; --muted:#6B7280; --success:#22C55E;
  --warning:#F59E0B; --gradient:linear-gradient(135deg,#6C63FF,#00D4FF);
  --sidebar-text:#C9CEDA; --sidebar-border:rgba(255,255,255,0.08); --page-alt:#E8EAEF;
}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Inter',sans-serif;background:var(--main-bg);color:var(--text);display:flex;min-height:100vh}

/* SIDEBAR */
#sidebar{width:260px;min-height:100vh;background:var(--sidebar-bg);border-right:1px solid var(--sidebar-border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:100;transition:all 0.3s}
#sidebar.collapsed{width:70px}
.sidebar-brand{padding:24px 20px;border-bottom:1px solid var(--sidebar-border);display:flex;align-items:center;gap:12px}
.sidebar-brand .brand-icon{width:38px;height:38px;border-radius:10px;background:var(--gradient);display:flex;align-items:center;justify-content:center;font-size:1.1rem;color:#fff;flex-shrink:0}
.sidebar-brand .brand-text{font-weight:800;font-size:1.1rem;background:var(--gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent;white-space:nowrap}
.nav-section{padding:16px 12px 8px;font-size:0.68rem;text-transform:uppercase;letter-spacing:2px;color:#9098A8;font-weight:700}
#sidebar.collapsed .nav-section,#sidebar.collapsed .sidebar-brand .brand-text,#sidebar.collapsed .sidebar-link span,#sidebar.collapsed .sidebar-badge{display:none}
#sidebar.collapsed{width:70px}
#sidebar.collapsed .sidebar-link{justify-content:center}
.sidebar-link{display:flex;align-items:center;gap:12px;padding:11px 16px;border-radius:10px;color:var(--sidebar-text);text-decoration:none;font-size:0.88rem;font-weight:500;margin:2px 8px;transition:all 0.2s;position:relative}
.sidebar-link:hover{color:#fff;background:rgba(255,255,255,0.08)}
.sidebar-link.active{color:#fff;background:rgba(108,99,255,0.35);border:1px solid rgba(108,99,255,0.4)}
.sidebar-link i{font-size:1.1rem;min-width:20px}
.sidebar-badge{background:var(--accent);color:#fff;font-size:0.65rem;padding:2px 7px;border-radius:10px;font-weight:700;margin-left:auto}
.sidebar-footer{margin-top:auto;padding:16px 12px;border-top:1px solid var(--sidebar-border)}
.admin-user{display:flex;align-items:center;gap:10px}
.admin-avatar{width:36px;height:36px;border-radius:50%;background:var(--gradient);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.95rem;color:#fff;flex-shrink:0}
.admin-info .name{font-size:0.85rem;font-weight:600;color:#fff;white-space:nowrap}
.admin-info .role{font-size:0.72rem;color:#9098A8;text-transform:capitalize}

/* MAIN */
#mainContent{margin-left:260px;flex:1;transition:margin 0.3s}
#mainContent.expanded{margin-left:70px}

/* TOPBAR */
.topbar{background:#fff;border-bottom:1px solid var(--border);padding:14px 28px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:50}
.topbar-title{font-size:1.05rem;font-weight:700;color:var(--text)}
.topbar-actions{display:flex;align-items:center;gap:12px}
.topbar-btn{background:var(--main-bg);border:1px solid var(--border);color:var(--text);width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.2s;text-decoration:none}
.topbar-btn:hover{background:rgba(108,99,255,0.12);color:var(--primary-dark);border-color:rgba(108,99,255,0.3)}
.notif-badge{position:relative}
.notif-dot{position:absolute;top:-3px;right:-3px;width:8px;height:8px;background:var(--accent);border-radius:50%;border:2px solid #fff}

/* PAGE */
.page-body{padding:28px;background:linear-gradient(180deg,var(--main-bg) 0%,var(--page-alt) 100%);min-height:calc(100vh - 65px)}

/* STAT CARDS */
.stat-card{background:var(--card-bg);border:1px solid var(--border);border-radius:16px;padding:24px;transition:all 0.3s;position:relative;overflow:hidden;box-shadow:0 1px 3px rgba(17,24,39,0.04)}
.stat-card::after{content:'';position:absolute;top:0;right:0;width:80px;height:80px;border-radius:50%;opacity:0.08;transform:translate(20px,-20px)}
.stat-card:hover{transform:translateY(-3px);box-shadow:0 12px 30px rgba(17,24,39,0.1)}
.stat-card.primary::after{background:var(--primary)}
.stat-card.secondary::after{background:var(--secondary);background-color:var(--secondary)}
.stat-card.success::after{background:var(--success)}
.stat-card.warning::after{background:var(--warning)}
.stat-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:#fff;margin-bottom:16px}
.stat-icon.primary{background:rgba(108,99,255,0.12);color:var(--primary)}
.stat-icon.secondary{background:rgba(0,168,204,0.12);color:var(--secondary)}
.stat-icon.success{background:rgba(34,197,94,0.12);color:var(--success)}
.stat-icon.warning{background:rgba(245,158,11,0.12);color:var(--warning)}
.stat-num{font-size:2rem;font-weight:800;color:var(--text);line-height:1}
.stat-label{font-size:0.82rem;color:var(--muted);margin-top:4px;font-weight:500}
.stat-trend{font-size:0.78rem;font-weight:600;margin-top:10px}
.trend-up{color:var(--success)}.trend-down{color:var(--accent)}

/* CHART CARDS */
.chart-card{background:var(--card-bg);border:1px solid var(--border);border-radius:16px;padding:24px;box-shadow:0 1px 3px rgba(17,24,39,0.04)}
.chart-card-title{font-size:1rem;font-weight:700;color:var(--text);margin-bottom:4px}
.chart-card-sub{font-size:0.8rem;color:var(--muted);margin-bottom:20px}

/* TABLE */
.data-table{width:100%;border-collapse:separate;border-spacing:0}
.data-table th{background:var(--main-bg);color:var(--muted);font-size:0.75rem;text-transform:uppercase;letter-spacing:1px;padding:12px 16px;border-bottom:1px solid var(--border);font-weight:600}
.data-table td{padding:13px 16px;border-bottom:1px solid var(--border);font-size:0.88rem;vertical-align:middle;color:var(--text)}
.data-table tr:hover td{background:rgba(17,24,39,0.02)}
.status-badge{padding:4px 10px;border-radius:20px;font-size:0.72rem;font-weight:600}
.status-new{background:rgba(108,99,255,0.12);color:var(--primary-dark)}
.status-read{background:rgba(0,168,204,0.12);color:var(--secondary)}
.status-replied{background:rgba(34,197,94,0.12);color:#16803C}
.status-archived{background:rgba(17,24,39,0.06);color:var(--muted)}

/* QUICK ACTIONS */
.quick-action{background:var(--card-bg);border:1px solid var(--border);border-radius:14px;padding:20px;text-align:center;text-decoration:none;color:var(--text);transition:all 0.3s;display:block;box-shadow:0 1px 3px rgba(17,24,39,0.04)}
.quick-action:hover{border-color:rgba(108,99,255,0.4);background:rgba(108,99,255,0.06);color:var(--primary-dark);transform:translateY(-3px)}
.quick-action i{font-size:1.6rem;margin-bottom:10px;display:block}

/* Page tabs */
.page-section{display:none}
.page-section.active{display:block}

/* Override Bootstrap text-white for light theme cards (chart-card/stat-card backgrounds are white) */
.text-white{color:var(--text) !important}
/* Exceptions: text on dark/gradient surfaces (sidebar, gradient buttons/badges, avatars) stays literal white */
.sidebar-link .text-white,
.chat-header .text-white,
.topbar-btn .text-white,
.modal .text-white{color:#fff !important}

@media(max-width:768px){
  #sidebar{transform:translateX(-100%)}
  #sidebar.mobile-open{transform:translateX(0)}
  #mainContent{margin-left:0}
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<nav id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="bi bi-hexagon-fill"></i></div>
    <div class="brand-text">Solution AI Admin</div>
  </div>

  <div style="overflow-y:auto;flex:1">
    <div class="nav-section">Main</div>
    <a class="sidebar-link active" href="#" onclick="showPage('dashboard',this)"><i class="bi bi-grid-fill"></i><span>Dashboard</span></a>
    <a class="sidebar-link" href="#" onclick="showPage('inquiries',this)"><i class="bi bi-envelope-fill"></i><span>Inquiries</span><span class="sidebar-badge"><?= $newInquiries ?></span></a>
    <a class="sidebar-link" href="#" onclick="showPage('chatbot',this)"><i class="bi bi-chat-dots-fill"></i><span>Chatbot</span></a>

    <div class="nav-section">Analytics</div>
    <a class="sidebar-link" href="#" onclick="showPage('analytics',this)"><i class="bi bi-bar-chart-line-fill"></i><span>Analytics</span></a>
    <a class="sidebar-link" href="#" onclick="showPage('reports',this)"><i class="bi bi-file-earmark-bar-graph-fill"></i><span>Reports</span></a>
    <a class="sidebar-link" href="#" onclick="showPage('leads',this)"><i class="bi bi-person-lines-fill"></i><span>Leads</span></a>

    <div class="nav-section">System</div>
    <a class="sidebar-link" href="#" onclick="showPage('settings',this)"><i class="bi bi-gear-fill"></i><span>Settings</span></a>
    <a class="sidebar-link" href="../index.php" target="_blank"><i class="bi bi-globe"></i><span>View Website</span></a>
    <a class="sidebar-link" href="logout.php"><i class="bi bi-box-arrow-left"></i><span>Logout</span></a>
  </div>

  <div class="sidebar-footer">
    <div class="admin-user">
      <div class="admin-avatar"><?= strtoupper(substr($adminName,0,1)) ?></div>
      <div class="admin-info">
        <div class="name"><?= htmlspecialchars($adminName) ?></div>
        <div class="role"><?= $_SESSION['admin_role'] ?></div>
      </div>
    </div>
  </div>
</nav>

<!-- MAIN CONTENT -->
<div id="mainContent">
  <!-- TOPBAR -->
  <div class="topbar">
    <div class="d-flex align-items-center gap-3">
      <button class="topbar-btn" onclick="toggleSidebar()"><i class="bi bi-list"></i></button>
      <div class="topbar-title" id="pageTitle">Dashboard Overview</div>
    </div>
    <div class="topbar-actions">
      <a href="inquiries-export.php" class="topbar-btn" title="Export Data"><i class="bi bi-download"></i></a>
      <div class="topbar-btn notif-badge" title="Notifications">
        <i class="bi bi-bell"></i>
        <?php if ($newInquiries > 0): ?><div class="notif-dot"></div><?php endif; ?>
      </div>
      <div class="topbar-btn" style="background:var(--gradient);border:none;color:#fff;font-weight:700;font-size:0.85rem;width:auto;padding:0 14px;border-radius:20px;">
        <?= date('D, d M Y') ?>
      </div>
    </div>
  </div>

  <div class="page-body">

    <!-- ===== DASHBOARD PAGE ===== -->
    <div class="page-section active" id="page-dashboard">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h4 class="text-white fw-800 mb-1">Welcome back, <?= htmlspecialchars($adminName) ?>! 👋</h4>
          <p class="text-muted small mb-0">Here's what's happening with Solution AI today.</p>
        </div>
      </div>

      <!-- Stat Cards -->
      <div class="row g-3 mb-4">
        <div class="col-lg-3 col-sm-6">
          <div class="stat-card primary">
            <div class="stat-icon primary"><i class="bi bi-envelope-fill"></i></div>
            <div class="stat-num"><?= number_format($totalInquiries) ?></div>
            <div class="stat-label">Total Inquiries</div>
            <div class="stat-trend trend-up"><i class="bi bi-arrow-up-right me-1"></i><?= $todayInquiries ?> today</div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="stat-card secondary">
            <div class="stat-icon secondary"><i class="bi bi-bell-fill"></i></div>
            <div class="stat-num"><?= $newInquiries ?></div>
            <div class="stat-label">New / Unread</div>
            <div class="stat-trend" style="color:var(--accent)"><i class="bi bi-clock me-1"></i>Needs attention</div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="stat-card success">
            <div class="stat-icon success"><i class="bi bi-cpu-fill"></i></div>
            <div class="stat-num"><?= $totalServices ?></div>
            <div class="stat-label">Active Services</div>
            <div class="stat-trend trend-up"><i class="bi bi-check-circle me-1"></i>All active</div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="stat-card warning">
            <div class="stat-icon warning"><i class="bi bi-chat-dots-fill"></i></div>
            <div class="stat-num"><?= $totalLeads ?></div>
            <div class="stat-label">Chat Leads</div>
            <div class="stat-trend trend-up"><i class="bi bi-robot me-1"></i><?= $totalChats ?> total chats</div>
          </div>
        </div>
      </div>

      <!-- Charts Row -->
      <div class="row g-3 mb-4">
        <div class="col-lg-8">
          <div class="chart-card">
            <div class="chart-card-title">Monthly Inquiries</div>
            <div class="chart-card-sub">Contact form submissions over the last 6 months</div>
            <canvas id="monthlyChart" height="100"></canvas>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="chart-card">
            <div class="chart-card-title">Inquiry Status</div>
            <div class="chart-card-sub">Current status breakdown</div>
            <canvas id="statusChart" height="200"></canvas>
          </div>
        </div>
      </div>

      <!-- Recent Inquiries Table -->
      <div class="chart-card mb-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
          <div>
            <div class="chart-card-title">Recent Inquiries</div>
            <div class="chart-card-sub mb-0">Latest contact form submissions</div>
          </div>
          <a href="#" onclick="showPage('inquiries')" class="btn btn-sm" style="background:rgba(108,99,255,0.15);color:var(--primary);border:1px solid rgba(108,99,255,0.3);border-radius:8px;font-size:0.8rem">View All</a>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr><th>Name</th><th>Company</th><th>Country</th><th>Job Title</th><th>Status</th><th>Date</th><th>Action</th></tr>
            </thead>
            <tbody>
              <?php foreach (array_slice($recentInquiries, 0, 8) as $inq): ?>
              <tr>
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <div style="width:32px;height:32px;border-radius:50%;background:var(--gradient);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.8rem;color:#fff;flex-shrink:0">
                      <?= strtoupper(substr($inq['name'],0,1)) ?>
                    </div>
                    <div>
                      <div style="font-weight:600;color:var(--text);font-size:0.88rem"><?= htmlspecialchars($inq['name']) ?></div>
                      <div style="font-size:0.75rem;color:var(--muted)"><?= htmlspecialchars($inq['email']) ?></div>
                    </div>
                  </div>
                </td>
                <td style="color:var(--text)"><?= htmlspecialchars($inq['company_name']) ?></td>
                <td><span style="font-size:0.83rem"><?= htmlspecialchars($inq['country']) ?></span></td>
                <td style="color:var(--muted);font-size:0.83rem"><?= htmlspecialchars($inq['job_title']) ?></td>
                <td><span class="status-badge status-<?= $inq['status'] ?>"><?= ucfirst($inq['status']) ?></span></td>
                <td style="color:var(--muted);font-size:0.8rem"><?= date('d M Y', strtotime($inq['created_at'])) ?></td>
                <td>
                  <div class="d-flex gap-2">
                    <button class="btn btn-sm" style="background:rgba(108,99,255,0.15);color:var(--primary);border:none;border-radius:6px;padding:4px 10px;font-size:0.75rem" onclick="viewInquiry(<?= $inq['id'] ?>)">View</button>
                    <button class="btn btn-sm" style="background:rgba(34,197,94,0.1);color:var(--success);border:none;border-radius:6px;padding:4px 10px;font-size:0.75rem" onclick="openReplyModal(<?= $inq['id'] ?>, '<?= htmlspecialchars($inq['name'], ENT_QUOTES) ?>', '<?= htmlspecialchars($inq['email'], ENT_QUOTES) ?>')">Reply</button>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($recentInquiries)): ?>
              <tr><td colspan="7" class="text-center py-4" style="color:var(--muted)"><i class="bi bi-inbox fs-2 d-block mb-2"></i>No inquiries yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="row g-3">
        <div class="col-12"><h6 class="text-white fw-700 mb-3">Quick Actions</h6></div>
        <?php
        $actions = [
          ['icon'=>'bi-envelope-plus-fill','label'=>'View All Inquiries','color'=>'var(--primary)','page'=>'inquiries'],
          ['icon'=>'bi-chat-square-dots-fill','label'=>'Chat Conversations','color'=>'var(--secondary)','page'=>'chatbot'],
          ['icon'=>'bi-bar-chart-fill','label'=>'Analytics Report','color'=>'var(--accent)','page'=>'analytics'],
          ['icon'=>'bi-people-fill','label'=>'Lead Management','color'=>'#FBBF24','page'=>'leads'],
        ];
        foreach ($actions as $a): ?>
        <div class="col-lg-3 col-md-6">
          <a class="quick-action" href="#" onclick="showPage('<?= $a['page'] ?>')">
            <i class="bi <?= $a['icon'] ?>" style="color:<?= $a['color'] ?>"></i>
            <?= $a['label'] ?>
          </a>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- ===== INQUIRIES PAGE ===== -->
    <div class="page-section" id="page-inquiries">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h4 class="text-white fw-800 mb-1">Contact Inquiries</h4>
          <p class="text-muted small mb-0">All customer contact form submissions</p>
        </div>
        <a href="inquiries-export.php" class="btn" style="background:var(--gradient);color:#fff;border:none;border-radius:10px;padding:10px 20px;font-weight:600;font-size:0.88rem">
          <i class="bi bi-download me-2"></i>Export CSV
        </a>
      </div>

      <!-- Filters -->
      <div class="chart-card mb-3">
        <div class="row g-3 align-items-center">
          <div class="col-md-4">
            <input type="text" class="form-control" id="searchInq" placeholder="Search name, email, company..." style="background:var(--main-bg);border:1px solid var(--border);color:var(--text);border-radius:10px;padding:10px 14px">
          </div>
          <div class="col-md-3">
            <select class="form-select" id="filterStatus" style="background:var(--main-bg);border:1px solid var(--border);color:var(--text);border-radius:10px;padding:10px">
              <option value="">All Status</option>
              <option>new</option><option>read</option><option>replied</option><option>archived</option>
            </select>
          </div>
          <div class="col-md-3">
            <select class="form-select" id="filterCountry" style="background:var(--main-bg);border:1px solid var(--border);color:var(--text);border-radius:10px;padding:10px">
              <option value="">All Countries</option>
              <?php foreach ($countryData as $c): ?>
              <option><?= htmlspecialchars($c['country']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-2">
            <button onclick="filterInquiries()" class="btn w-100" style="background:rgba(108,99,255,0.12);border:1px solid rgba(108,99,255,0.3);color:var(--primary-dark);border-radius:10px;padding:10px">
              <i class="bi bi-funnel me-1"></i>Filter
            </button>
          </div>
        </div>
      </div>

      <div class="chart-card">
        <div class="table-responsive">
          <table class="data-table" id="inquiriesTable">
            <thead>
              <tr><th>#</th><th>Name</th><th>Contact</th><th>Company</th><th>Country</th><th>Job Title</th><th>Status</th><th>Date</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <?php
              $all = $db->query("SELECT * FROM contact_inquiries ORDER BY created_at DESC")->fetchAll();
              foreach ($all as $inq): ?>
              <tr data-status="<?= $inq['status'] ?>" data-country="<?= htmlspecialchars($inq['country']) ?>">
                <td style="color:var(--muted);font-size:0.8rem">#<?= $inq['id'] ?></td>
                <td>
                  <div style="font-weight:600;color:var(--text)"><?= htmlspecialchars($inq['name']) ?></div>
                </td>
                <td>
                  <div style="font-size:0.82rem;color:var(--text)"><?= htmlspecialchars($inq['email']) ?></div>
                  <div style="font-size:0.78rem;color:var(--muted)"><?= htmlspecialchars($inq['phone']) ?></div>
                </td>
                <td style="font-size:0.85rem"><?= htmlspecialchars($inq['company_name']) ?></td>
                <td style="font-size:0.83rem"><?= htmlspecialchars($inq['country']) ?></td>
                <td style="font-size:0.83rem;color:var(--muted)"><?= htmlspecialchars($inq['job_title']) ?></td>
                <td>
                  <select class="status-badge status-<?= $inq['status'] ?>" onchange="updateStatus(<?= $inq['id'] ?>,this)" style="border:none;background:transparent;cursor:pointer;font-weight:600;font-size:0.72rem">
                    <?php foreach(['new','read','replied','archived'] as $s): ?>
                    <option value="<?= $s ?>" <?= $inq['status']===$s?'selected':'' ?> style="background:#fff;color:#1a1a2e"><?= ucfirst($s) ?></option>
                    <?php endforeach; ?>
                  </select>
                </td>
                <td style="font-size:0.8rem;color:var(--muted)"><?= date('d M Y<br>H:i', strtotime($inq['created_at'])) ?></td>
                <td>
                  <div class="d-flex gap-1">
                    <button class="btn btn-sm" style="background:rgba(108,99,255,0.15);color:var(--primary);border:none;border-radius:6px;padding:4px 8px" onclick="viewInquiry(<?= $inq['id'] ?>)" title="View Details"><i class="bi bi-eye"></i></button>
                    <button class="btn btn-sm" style="background:rgba(34,197,94,0.1);color:var(--success);border:none;border-radius:6px;padding:4px 8px" title="Reply via Email" onclick="openReplyModal(<?= $inq['id'] ?>, '<?= htmlspecialchars($inq['name'], ENT_QUOTES) ?>', '<?= htmlspecialchars($inq['email'], ENT_QUOTES) ?>')"><i class="bi bi-reply"></i></button>
                    <button class="btn btn-sm" style="background:rgba(239,68,68,0.1);color:#ef4444;border:none;border-radius:6px;padding:4px 8px" onclick="deleteInquiry(<?= $inq['id'] ?>)" title="Delete"><i class="bi bi-trash"></i></button>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($all)): ?>
              <tr><td colspan="9" class="text-center py-5" style="color:var(--muted)"><i class="bi bi-inbox fs-1 d-block mb-2 opacity-25"></i>No inquiries received yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ===== ANALYTICS PAGE ===== -->
    <div class="page-section" id="page-analytics">
      <div class="mb-4">
        <h4 class="text-white fw-800 mb-1">Analytics Dashboard</h4>
        <p class="text-muted small">Comprehensive performance metrics and insights</p>
      </div>
      <div class="row g-3 mb-4">
        <div class="col-lg-3 col-sm-6">
          <div class="stat-card primary">
            <div class="stat-icon primary"><i class="bi bi-envelope-fill"></i></div>
            <div class="stat-num"><?= $totalInquiries ?></div>
            <div class="stat-label">Total Inquiries</div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="stat-card success">
            <div class="stat-icon success"><i class="bi bi-person-check-fill"></i></div>
            <div class="stat-num"><?= $totalLeads ?></div>
            <div class="stat-label">AI Chat Leads</div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="stat-card secondary">
            <div class="stat-icon secondary"><i class="bi bi-chat-fill"></i></div>
            <div class="stat-num"><?= $totalChats ?></div>
            <div class="stat-label">Chat Sessions</div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="stat-card warning">
            <div class="stat-icon warning"><i class="bi bi-percent"></i></div>
            <div class="stat-num"><?= $totalChats > 0 ? round(($totalLeads/$totalChats)*100) : 0 ?>%</div>
            <div class="stat-label">Conversion Rate</div>
          </div>
        </div>
      </div>
      <div class="row g-3">
        <div class="col-lg-8">
          <div class="chart-card">
            <div class="chart-card-title">Inquiry Trends</div>
            <div class="chart-card-sub">Monthly overview</div>
            <canvas id="analyticsChart" height="120"></canvas>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="chart-card">
            <div class="chart-card-title">Top Countries</div>
            <div class="chart-card-sub">Inquiries by location</div>
            <canvas id="countryChart" height="260"></canvas>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== CHATBOT PAGE ===== -->
    <div class="page-section" id="page-chatbot">
      <div class="mb-4">
        <h4 class="text-white fw-800 mb-1">Chatbot Conversations</h4>
        <p class="text-muted small">All AI chatbot sessions and leads</p>
      </div>
      <?php
      $sessions = $db->query("SELECT * FROM chat_sessions ORDER BY started_at DESC LIMIT 50")->fetchAll();
      ?>
      <div class="chart-card">
        <div class="table-responsive">
          <table class="data-table">
            <thead><tr><th>#</th><th>Visitor</th><th>Email</th><th>Company</th><th>Lead</th><th>Score</th><th>Messages</th><th>Started</th></tr></thead>
            <tbody>
              <?php foreach ($sessions as $s):
                $msgCount = $db->prepare("SELECT COUNT(*) FROM chat_messages WHERE session_id=?");
                $msgCount->execute([$s['session_id']]);
              ?>
              <tr>
                <td style="color:var(--muted);font-size:0.8rem"><?= $s['id'] ?></td>
                <td style="color:var(--text);font-weight:600"><?= htmlspecialchars($s['visitor_name'] ?: 'Anonymous') ?></td>
                <td style="font-size:0.83rem"><?= htmlspecialchars($s['visitor_email'] ?: '—') ?></td>
                <td style="font-size:0.83rem"><?= htmlspecialchars($s['company_name'] ?: '—') ?></td>
                <td><?= $s['is_lead'] ? '<span class="status-badge status-replied">Lead</span>' : '<span class="status-badge status-archived">No</span>' ?></td>
                <td><span style="color:var(--warning);font-weight:700"><?= $s['lead_score'] ?></span></td>
                <td><?= $msgCount->fetchColumn() ?></td>
                <td style="font-size:0.8rem;color:var(--muted)"><?= date('d M H:i', strtotime($s['started_at'])) ?></td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($sessions)): ?>
              <tr><td colspan="8" class="text-center py-5" style="color:var(--muted)"><i class="bi bi-chat-dots fs-1 d-block mb-2 opacity-25"></i>No chat sessions yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ===== LEADS PAGE ===== -->
    <div class="page-section" id="page-leads">
      <div class="mb-4">
        <h4 class="text-white fw-800 mb-1">Lead Management</h4>
        <p class="text-muted small">Qualified leads from AI chatbot interactions</p>
      </div>
      <?php $leads = $db->query("SELECT * FROM chat_sessions WHERE is_lead=1 ORDER BY started_at DESC")->fetchAll(); ?>
      <div class="chart-card">
        <div class="table-responsive">
          <table class="data-table">
            <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Company</th><th>Industry</th><th>Service</th><th>Budget</th><th>Score</th><th>Date</th></tr></thead>
            <tbody>
              <?php foreach ($leads as $l): ?>
              <tr>
                <td style="color:var(--text);font-weight:600"><?= htmlspecialchars($l['visitor_name'] ?: '—') ?></td>
                <td style="font-size:0.83rem"><a href="mailto:<?= $l['visitor_email'] ?>" style="color:var(--primary)"><?= htmlspecialchars($l['visitor_email'] ?: '—') ?></a></td>
                <td style="font-size:0.83rem"><?= htmlspecialchars($l['visitor_phone'] ?: '—') ?></td>
                <td style="font-size:0.83rem"><?= htmlspecialchars($l['company_name'] ?: '—') ?></td>
                <td style="font-size:0.83rem"><?= htmlspecialchars($l['industry'] ?: '—') ?></td>
                <td style="font-size:0.83rem"><?= htmlspecialchars($l['required_service'] ?: '—') ?></td>
                <td style="font-size:0.83rem"><?= htmlspecialchars($l['budget'] ?: '—') ?></td>
                <td><span style="background:rgba(251,191,36,0.15);color:var(--warning);padding:3px 10px;border-radius:20px;font-size:0.75rem;font-weight:700"><?= $l['lead_score'] ?></span></td>
                <td style="font-size:0.8rem;color:var(--muted)"><?= date('d M Y', strtotime($l['started_at'])) ?></td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($leads)): ?>
              <tr><td colspan="9" class="text-center py-5" style="color:var(--muted)"><i class="bi bi-person-lines-fill fs-1 d-block mb-2 opacity-25"></i>No leads captured yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ===== SETTINGS PAGE ===== -->
    <div class="page-section" id="page-settings">
      <div class="mb-4">
        <h4 class="text-white fw-800 mb-1">Settings</h4>
        <p class="text-muted small">Manage your admin account and system settings</p>
      </div>
      <div class="row g-4">
        <div class="col-lg-6">
          <div class="chart-card">
            <h6 class="text-white fw-700 mb-4">Change Password</h6>
            <form action="update-password.php" method="POST">
              <input type="hidden" name="csrf_token" value="<?= generateCsrf() ?>">
              <div class="mb-3">
                <label class="form-label" style="color:var(--text);font-size:0.85rem;font-weight:600">Current Password</label>
                <input type="password" name="current_password" class="form-control" style="background:var(--main-bg);border:1px solid var(--border);color:var(--text);border-radius:10px;padding:10px" required>
              </div>
              <div class="mb-3">
                <label class="form-label" style="color:var(--text);font-size:0.85rem;font-weight:600">New Password</label>
                <input type="password" name="new_password" class="form-control" style="background:var(--main-bg);border:1px solid var(--border);color:var(--text);border-radius:10px;padding:10px" required>
              </div>
              <div class="mb-4">
                <label class="form-label" style="color:var(--text);font-size:0.85rem;font-weight:600">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" style="background:var(--main-bg);border:1px solid var(--border);color:var(--text);border-radius:10px;padding:10px" required>
              </div>
              <button type="submit" class="btn" style="background:var(--gradient);color:#fff;border:none;border-radius:10px;padding:10px 24px;font-weight:600">Update Password</button>
            </form>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="chart-card">
            <h6 class="text-white fw-700 mb-4">API Configuration</h6>
            <p class="text-muted small mb-3">Configure your AI API key in <code style="color:var(--primary)">php/config.php</code></p>
            <div class="p-3 rounded-3 mb-3" style="background:rgba(108,99,255,0.08);border:1px solid rgba(108,99,255,0.2)">
              <div class="d-flex justify-content-between mb-2">
                <span class="small text-muted">Claude API Status</span>
                <?php $hasKey = CLAUDE_API_KEY !== 'YOUR_CLAUDE_API_KEY_HERE'; ?>
                <span class="small fw-600" style="color:<?= $hasKey?'var(--success)':'var(--accent)' ?>"><?= $hasKey?'✓ Configured':'✗ Not Set' ?></span>
              </div>
              <div class="d-flex justify-content-between">
                <span class="small text-muted">Model</span>
                <span class="small fw-600 text-white"><?= CLAUDE_MODEL ?></span>
              </div>
            </div>
            <p class="text-muted" style="font-size:0.8rem">Open <code style="color:var(--secondary)">php/config.php</code> and replace <code>'YOUR_CLAUDE_API_KEY_HERE'</code> with your actual API key.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== OTHER PLACEHOLDERS ===== -->
    <div class="page-section" id="page-reports">
      <div class="mb-4"><h4 class="text-white fw-800 mb-1">Reports</h4><p class="text-muted small">Generate and export reports</p></div>
      <div class="row g-3">
        <?php
        $reports = [
          ['icon'=>'bi-file-earmark-spreadsheet-fill','title'=>'Inquiries Export','desc'=>'Export all contact inquiries to CSV','link'=>'inquiries-export.php','color'=>'var(--success)'],
          ['icon'=>'bi-file-earmark-person-fill','title'=>'Leads Report','desc'=>'Export chatbot-generated leads to CSV','link'=>'leads-export.php','color'=>'var(--warning)'],
          ['icon'=>'bi-file-earmark-bar-graph-fill','title'=>'Monthly Summary','desc'=>'Monthly analytics summary report','link'=>'#','color'=>'var(--primary)'],
        ];
        foreach ($reports as $r): ?>
        <div class="col-md-4">
          <div class="chart-card text-center">
            <i class="bi <?= $r['icon'] ?>" style="font-size:2.5rem;color:<?= $r['color'] ?>;margin-bottom:16px;display:block"></i>
            <h6 class="text-white fw-700 mb-2"><?= $r['title'] ?></h6>
            <p class="text-muted small mb-3"><?= $r['desc'] ?></p>
            <a href="<?= $r['link'] ?>" class="btn btn-sm" style="background:var(--main-bg);border:1px solid var(--border);color:var(--text);border-radius:8px;padding:8px 20px">Download <i class="bi bi-download ms-1"></i></a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div><!-- /page-body -->
</div><!-- /mainContent -->

<!-- Reply Modal -->
<div class="modal fade" id="replyModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content" style="background:#111827;border:1px solid rgba(255,255,255,0.08);border-radius:16px">
      <div class="modal-header" style="border-color:rgba(255,255,255,0.08);padding:20px 24px">
        <div>
          <h5 class="modal-title text-white fw-700 mb-0" style="font-size:1rem">
            <i class="bi bi-send-fill me-2" style="color:#6C63FF"></i>Reply to Inquiry
          </h5>
          <p class="mb-0 mt-1" style="color:#9098A8;font-size:0.8rem" id="replyRecipientLabel">Sending to: —</p>
        </div>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" style="padding:24px">

        <!-- Info banner -->
        <div style="background:rgba(108,99,255,0.1);border:1px solid rgba(108,99,255,0.25);border-radius:10px;padding:12px 16px;margin-bottom:20px;display:flex;align-items:center;gap:10px">
          <i class="bi bi-info-circle-fill" style="color:#6C63FF;font-size:1rem;flex-shrink:0"></i>
          <p style="margin:0;color:#C9CEDA;font-size:0.83rem">A professional branded email will be sent from <strong style="color:#fff">deepak.sah.450045@gmail.com</strong> to the client's inbox on behalf of Solution AI.</p>
        </div>

        <!-- Recipient -->
        <div style="margin-bottom:16px">
          <label style="color:#9098A8;font-size:0.75rem;text-transform:uppercase;letter-spacing:1px;font-weight:700;display:block;margin-bottom:6px">To</label>
          <div id="replyToDisplay" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:10px 14px;color:#E2E8F0;font-size:0.88rem"></div>
        </div>

        <!-- Subject (display-only) -->
        <div style="margin-bottom:16px">
          <label style="color:#9098A8;font-size:0.75rem;text-transform:uppercase;letter-spacing:1px;font-weight:700;display:block;margin-bottom:6px">Subject</label>
          <div id="replySubjectDisplay" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:10px 14px;color:#E2E8F0;font-size:0.88rem"></div>
        </div>

        <!-- Message -->
        <div style="margin-bottom:8px">
          <label style="color:#9098A8;font-size:0.75rem;text-transform:uppercase;letter-spacing:1px;font-weight:700;display:block;margin-bottom:6px">Your Reply</label>
          <textarea id="replyMessage" rows="7" placeholder="Type your professional reply here..." style="width:100%;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:14px;color:#E2E8F0;font-size:0.9rem;line-height:1.7;resize:vertical;font-family:inherit;outline:none;transition:border-color 0.2s" onfocus="this.style.borderColor='rgba(108,99,255,0.5)'" onblur="this.style.borderColor='rgba(255,255,255,0.1)'"></textarea>
          <p style="color:#6B7280;font-size:0.75rem;margin:6px 0 0">The message will be wrapped in a professional HTML email template automatically.</p>
        </div>

      </div>
      <div class="modal-footer" style="border-color:rgba(255,255,255,0.08);padding:16px 24px;gap:10px">
        <button type="button" class="btn" data-bs-dismiss="modal" style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:#C9CEDA;border-radius:8px;padding:8px 20px;font-size:0.85rem">Cancel</button>
        <button type="button" id="sendReplyBtn" onclick="sendReply()" style="background:linear-gradient(135deg,#6C63FF,#00D4FF);border:none;color:#fff;border-radius:8px;padding:8px 24px;font-size:0.85rem;font-weight:700;cursor:pointer;transition:opacity 0.2s">
          <i class="bi bi-send me-1"></i> Send Reply
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Inquiry Modal -->
<div class="modal fade" id="inquiryModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="background:#111827;border:1px solid rgba(255,255,255,0.08);border-radius:16px">
      <div class="modal-header" style="border-color:rgba(255,255,255,0.08)">
        <h5 class="modal-title text-white fw-700">Inquiry Details</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="inquiryModalBody" style="color:#E2E8F0"></div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Page Navigation
function showPage(page, el) {
  document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
  const sec = document.getElementById('page-' + page);
  if (sec) sec.classList.add('active');
  if (el) el.classList.add('active');
  const titles = {dashboard:'Dashboard Overview',inquiries:'Contact Inquiries',analytics:'Analytics',chatbot:'Chatbot Sessions',leads:'Lead Management',reports:'Reports',settings:'Settings'};
  document.getElementById('pageTitle').textContent = titles[page] || 'Dashboard';
  if (page === 'analytics') setTimeout(initAnalyticsCharts, 100);
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('collapsed');
  document.getElementById('mainContent').classList.toggle('expanded');
}

// Charts
const chartDefaults = { responsive: true, plugins: { legend: { labels: { color: '#6B7280', font: { size: 11 } } } }, scales: { x: { ticks: { color: '#6B7280' }, grid: { color: 'rgba(17,24,39,0.06)' } }, y: { ticks: { color: '#6B7280' }, grid: { color: 'rgba(17,24,39,0.06)' } } } };

const monthLabels = <?= json_encode(array_column($monthlyData, 'month')) ?>;
const monthCounts = <?= json_encode(array_map('intval', array_column($monthlyData, 'count'))) ?>;

// Monthly Chart
new Chart(document.getElementById('monthlyChart'), {
  type: 'bar',
  data: {
    labels: monthLabels.length ? monthLabels : ['No data'],
    datasets: [{ label: 'Inquiries', data: monthCounts.length ? monthCounts : [0], backgroundColor: 'rgba(108,99,255,0.5)', borderColor: '#6C63FF', borderWidth: 2, borderRadius: 8 }]
  },
  options: { ...chartDefaults, plugins: { ...chartDefaults.plugins, legend: { display: false } } }
});

// Status Doughnut
const statusMap = <?= json_encode($statusMap) ?>;
new Chart(document.getElementById('statusChart'), {
  type: 'doughnut',
  data: {
    labels: ['New','Read','Replied','Archived'],
    datasets: [{ data: [statusMap.new||0, statusMap.read||0, statusMap.replied||0, statusMap.archived||0], backgroundColor: ['rgba(108,99,255,0.7)','rgba(0,212,255,0.7)','rgba(34,197,94,0.7)','rgba(100,116,139,0.5)'], borderWidth: 0 }]
  },
  options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { color: '#6B7280', font: { size: 11 }, padding: 16 } } }, cutout: '65%' }
});

function initAnalyticsCharts() {
  // Analytics line chart
  const ac = document.getElementById('analyticsChart');
  if (ac && !ac.dataset.init) {
    ac.dataset.init = '1';
    new Chart(ac, {
      type: 'line',
      data: {
        labels: monthLabels.length ? monthLabels : ['No data'],
        datasets: [{ label: 'Inquiries', data: monthCounts, borderColor: '#6C63FF', backgroundColor: 'rgba(108,99,255,0.1)', fill: true, tension: 0.4, pointBackgroundColor: '#6C63FF', pointRadius: 5 }]
      },
      options: chartDefaults
    });
  }
  const cc = document.getElementById('countryChart');
  const countryLabels = <?= json_encode(array_column($countryData, 'country')) ?>;
  const countryCounts = <?= json_encode(array_map('intval', array_column($countryData, 'count'))) ?>;
  if (cc && !cc.dataset.init) {
    cc.dataset.init = '1';
    new Chart(cc, {
      type: 'bar',
      data: {
        labels: countryLabels.length ? countryLabels : ['No data'],
        datasets: [{ label: 'Inquiries', data: countryCounts, backgroundColor: ['rgba(108,99,255,0.6)','rgba(0,212,255,0.6)','rgba(255,101,132,0.6)','rgba(251,191,36,0.6)','rgba(34,197,94,0.6)','rgba(168,85,247,0.6)','rgba(249,115,22,0.6)','rgba(236,72,153,0.6)'], borderRadius: 6 }]
      },
      options: { ...chartDefaults, indexAxis: 'y', plugins: { legend: { display: false } }, scales: { ...chartDefaults.scales, x: { ...chartDefaults.scales.x, beginAtZero: true } } }
    });
  }
}

// Inquiry actions
const inquiries = <?= json_encode($all ?? []) ?>;
function viewInquiry(id) {
  const inq = inquiries.find(i => i.id == id);
  if (!inq) return;
  document.getElementById('inquiryModalBody').innerHTML = `
    <div class="row g-3">
      <div class="col-md-6"><small class="text-muted d-block">Name</small><strong>${inq.name}</strong></div>
      <div class="col-md-6"><small class="text-muted d-block">Email</small><a href="mailto:${inq.email}" style="color:#6C63FF">${inq.email}</a></div>
      <div class="col-md-6"><small class="text-muted d-block">Phone</small>${inq.phone || '—'}</div>
      <div class="col-md-6"><small class="text-muted d-block">Company</small>${inq.company_name || '—'}</div>
      <div class="col-md-6"><small class="text-muted d-block">Country</small>${inq.country || '—'}</div>
      <div class="col-md-6"><small class="text-muted d-block">Job Title</small>${inq.job_title || '—'}</div>
      <div class="col-12"><small class="text-muted d-block">Job Details</small><div style="background:rgba(255,255,255,0.04);border-radius:8px;padding:14px;margin-top:4px;font-size:0.9rem">${inq.job_details || '—'}</div></div>
      <div class="col-md-6"><small class="text-muted d-block">Submitted</small>${new Date(inq.created_at).toLocaleString()}</div>
      <div class="col-md-6"><small class="text-muted d-block">Status</small><span class="status-badge status-${inq.status}">${inq.status}</span></div>
    </div>`;
  new bootstrap.Modal(document.getElementById('inquiryModal')).show();
}

function updateStatus(id, el) {
  fetch('ajax/update-status.php', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({id,status:el.value}) })
    .then(r=>r.json()).then(d=>{ if(d.success){ el.className='status-badge status-'+el.value; } });
}

function deleteInquiry(id) {
  if (!confirm('Delete this inquiry? This cannot be undone.')) return;
  fetch('ajax/delete-inquiry.php', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({id}) })
    .then(r=>r.json()).then(d=>{ if(d.success) location.reload(); });
}

function filterInquiries() {
  const search = document.getElementById('searchInq').value.toLowerCase();
  const status = document.getElementById('filterStatus').value;
  const country = document.getElementById('filterCountry').value;
  document.querySelectorAll('#inquiriesTable tbody tr').forEach(row => {
    const text = row.textContent.toLowerCase();
    const rowStatus = row.dataset.status;
    const rowCountry = row.dataset.country;
    const show = (!search || text.includes(search)) && (!status || rowStatus === status) && (!country || rowCountry === country);
    row.style.display = show ? '' : 'none';
  });
}

document.getElementById('searchInq')?.addEventListener('input', filterInquiries);

// ===== REPLY MODAL =====
let _replyInquiryId = null;

function openReplyModal(id, name, email) {
  _replyInquiryId = id;
  document.getElementById('replyToDisplay').textContent   = name + ' <' + email + '>';
  document.getElementById('replySubjectDisplay').textContent = 'Re: Your Inquiry to Solution AI — Ref #INQ-' + id;
  document.getElementById('replyRecipientLabel').textContent = 'Sending to: ' + email;
  document.getElementById('replyMessage').value = '';
  const btn = document.getElementById('sendReplyBtn');
  btn.disabled = false;
  btn.innerHTML = '<i class="bi bi-send me-1"></i> Send Reply';
  new bootstrap.Modal(document.getElementById('replyModal')).show();
}

function sendReply() {
  const message = document.getElementById('replyMessage').value.trim();
  if (!message) {
    document.getElementById('replyMessage').style.borderColor = '#ef4444';
    document.getElementById('replyMessage').focus();
    return;
  }
  document.getElementById('replyMessage').style.borderColor = 'rgba(255,255,255,0.1)';

  const btn = document.getElementById('sendReplyBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Sending...';

  fetch('ajax/send-reply.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id: _replyInquiryId, message })
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      btn.innerHTML = '<i class="bi bi-check-lg me-1"></i> Sent!';
      btn.style.background = '#22C55E';
      setTimeout(() => {
        bootstrap.Modal.getInstance(document.getElementById('replyModal')).hide();
        location.reload();
      }, 1200);
    } else {
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-send me-1"></i> Send Reply';
      alert('Error: ' + (data.message || 'Could not send email. Please try again.'));
    }
  })
  .catch(() => {
    btn.disabled = false;
    btn.innerHTML = '<i class="bi bi-send me-1"></i> Send Reply';
    alert('Network error. Please check your connection and try again.');
  });
}
</script>
</body>
</html>
