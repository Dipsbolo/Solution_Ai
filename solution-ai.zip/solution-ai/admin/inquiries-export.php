<?php
require_once __DIR__ . '/../php/config.php';
requireAuth();

$db = getDB();
$rows = $db->query("SELECT id, name, email, phone, company_name, country, job_title, job_details, status, created_at FROM contact_inquiries ORDER BY created_at DESC")->fetchAll();

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="solution-ai-inquiries-' . date('Y-m-d') . '.csv"');
header('Pragma: no-cache');

$out = fopen('php://output', 'w');
fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF)); // UTF-8 BOM
fputcsv($out, ['ID','Name','Email','Phone','Company','Country','Job Title','Job Details','Status','Submitted At']);
foreach ($rows as $row) {
    fputcsv($out, $row);
}
fclose($out);
exit;
