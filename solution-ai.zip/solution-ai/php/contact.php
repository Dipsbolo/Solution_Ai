<?php
require_once __DIR__ . '/config.php';
startSecureSession();
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}

// CSRF check
$token = $_POST['csrf_token'] ?? '';
if (!validateCsrf($token)) {
    jsonResponse(['success' => false, 'message' => 'Invalid security token'], 403);
}

// Rate limiting
$ip = getClientIP();
$db = getDB();
$stmt = $db->prepare("SELECT COUNT(*) FROM contact_inquiries WHERE ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
$stmt->execute([$ip]);
if ($stmt->fetchColumn() >= 500) {
    jsonResponse(['success' => false, 'message' => 'Too many submissions. Please try again later.'], 429);
}

// Validate input
$required = ['name', 'email', 'phone', 'company_name', 'country', 'job_title', 'job_details'];
$errors = [];

$name = sanitize($_POST['name'] ?? '');
$email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$phone = sanitize($_POST['phone'] ?? '');
$company = sanitize($_POST['company_name'] ?? '');
$country = sanitize($_POST['country'] ?? '');
$job_title = sanitize($_POST['job_title'] ?? '');
$job_details = sanitize($_POST['job_details'] ?? '');

if (empty($name) || strlen($name) < 2) $errors[] = 'Name is required (min 2 characters)';
if (!$email) $errors[] = 'Valid email address is required';
if (empty($phone)) $errors[] = 'Phone number is required';
if (empty($company)) $errors[] = 'Company name is required';
if (empty($country)) $errors[] = 'Country is required';
if (empty($job_title)) $errors[] = 'Job title is required';
if (empty($job_details) || strlen($job_details) < 20) $errors[] = 'Job details are required (min 20 characters)';

if (!empty($errors)) {
    jsonResponse(['success' => false, 'message' => implode('. ', $errors)]);
}

// Insert into database
try {
    $stmt = $db->prepare("INSERT INTO contact_inquiries (name, email, phone, company_name, country, job_title, job_details, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $email, $phone, $company, $country, $job_title, $job_details, $ip]);
    jsonResponse(['success' => true, 'message' => 'Thank you! Your inquiry has been submitted. We will contact you within 24 hours.']);
} catch (PDOException $e) {
    jsonResponse(['success' => false, 'message' => 'An error occurred. Please try again.'], 500);
}
