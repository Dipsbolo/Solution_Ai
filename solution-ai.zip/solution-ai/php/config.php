<?php
// =============================================
// Solution AI - Configuration
// =============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'solution_ai');
define('DB_CHARSET', 'utf8mb4');

// Site Configuration
define('SITE_NAME', 'Solution AI');
define('SITE_URL', 'http://localhost/solution-ai');
define('ADMIN_EMAIL', 'kit24h.dps@ismt.edu.np');

// Session Configuration
define('SESSION_LIFETIME', 3600); // 1 hour
define('SESSION_NAME', 'solution_ai_admin');

// Security
define('CSRF_TOKEN_NAME', 'solution_ai_csrf');
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 60); // 15 minutes

// Rate Limiting for Chatbot
define('CHAT_RATE_LIMIT', 30); // messages per minute
define('CHAT_SESSION_EXPIRE', 3600); // 1 hour

// API Keys (set your keys here)
define('CLAUDE_API_KEY', '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');
define('CLAUDE_MODEL', 'claude-sonnet-4-6');

// =============================================
// Database Connection (PDO)
// =============================================
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'Database connection failed']));
        }
    }
    return $pdo;
}

// =============================================
// Security Helpers
// =============================================
function sanitize(string $input): string {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function generateCsrf(): string {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

function validateCsrf(string $token): bool {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

function getClientIP(): string {
    $keys = ['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR'];
    foreach ($keys as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = explode(',', $_SERVER[$key])[0];
            return filter_var(trim($ip), FILTER_VALIDATE_IP) ?: 'unknown';
        }
    }
    return 'unknown';
}

function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Start secure session
function startSecureSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path' => '/',
            'secure' => isset($_SERVER['HTTPS']),
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        session_start();
    }
}

function requireAuth(): void {
    startSecureSession();
    if (empty($_SESSION['admin_id'])) {
        header('Location: ' . SITE_URL . '/admin/login.php');
        exit;
    }
    // Regenerate session ID periodically
    if (empty($_SESSION['last_regenerate']) || time() - $_SESSION['last_regenerate'] > 300) {
        session_regenerate_id(true);
        $_SESSION['last_regenerate'] = time();
    }
}

// =============================================
// Email Configuration (Gmail SMTP)
// =============================================
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'deepak.sah.450045@gmail.com');
define('MAIL_PASSWORD', 'azjg wovs xkcb ohgg');
define('MAIL_FROM_NAME', 'Solution AI');
